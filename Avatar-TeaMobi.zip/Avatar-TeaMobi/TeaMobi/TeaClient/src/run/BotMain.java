/**
 * 
 */
package run;

import game.GameMidlet;

/**
 * @author Quynh Lam
 * 
 */
public class BotMain {
    static final int nBot = 100;

    public static void main(String[] args) {
        new Thread(new Runnable() {
            public void run() {
                while (true) {
                    System.out.println("Request:" + BotController.requestCount + " Login:" + BotController.successCount);
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }

        }).start();
        for (byte map = 0; map < 3; map++)
            for (int b = 0; b < 100; b++) {
                try {
                    Thread.sleep(100);
                    new BotController(GameMidlet.IP, GameMidlet.PORT, "b" + b + "_" + map, map).start();
                } catch (InterruptedException e) {
                }
            }
    }
}
