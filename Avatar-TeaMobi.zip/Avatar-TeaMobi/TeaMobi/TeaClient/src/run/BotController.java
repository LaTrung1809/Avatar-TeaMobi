/**
 * 
 */
package run;

import game.model.AttackInfo;
import game.model.CharInfo;
import game.model.MonsterInfo;
import game.networklogic.GameService;
import game.networklogic.IGameLogicHandler;
import game.networklogic.MessageHandler;
import game.render.screen.GameScr;

import java.util.Random;

import network.ISession;
import network.Session_SE;

/**
 * @author Quynh Lam
 * 
 */
public class BotController implements Runnable, IGameLogicHandler {

    /**
     * @param ip
     * @param port
     * @param string
     */
    static int requestCount, successCount;
    ISession ses = new Session_SE();
    MessageHandler msgHandler = new MessageHandler();
    GameService gameService = new GameService();
    GameScr gameScreen = new GameScr();
    String username;
    boolean isFree = false;
    static Random r = new Random();
    static {
        r.setSeed(System.currentTimeMillis());
    }

    public BotController(String ip, int port, String username, byte mapID) {
        requestCount++;
        this.username = username;
        msgHandler.setGameLogicHandler(this);
        ses.setHandler(msgHandler);
        gameService.setSession(ses);
        gameScreen.gameService = gameService;
        ses.connect(ip, port);
        gameService.login(username, username, mapID);
    }

    public void start() {
        new Thread(this).start();

    }

    public void run() {
        while (true) {
            if (isFree) {
                int dx = r.nextInt(32) - 16;
                int dy = r.nextInt(32) - 16;
                gameScreen.mainChar.x += dx;
                gameScreen.mainChar.y += dy;
                if (gameScreen.mainChar.x < 10)
                    gameScreen.mainChar.x = 30;
                if (gameScreen.mainChar.y < 10)
                    gameScreen.mainChar.x = 30;
                gameService.moveChar(gameScreen.mainChar.x, gameScreen.mainChar.y);
            }

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
            }
        }
    }

    public void charOutGame(short charID) {
        gameScreen.charOutGame(charID);
    }

    public void onActorMove(short actorType, short actorID, short x2, short y2) {
        gameScreen.onActorMove(actorType, actorID, x2, y2);
    }

    public void onCharInfo(CharInfo charInfo) {
        gameScreen.onCharInfo(charInfo);
    }

    public void onConnectFail() {
        System.out.println("CONNECT FAIL");
    }

    public void onConnectOK() {
    }

    public void onDisconnect() {
        System.out.println("DISCONNECT");
    }

    public void onInfoMainChar(CharInfo mainCharInfo) {
        gameScreen.onInfoMainChar(mainCharInfo);
        successCount++;
        // isFree = true;
    }

    public void onLoginSuccess() {
    }

    public void onMonsterAttackPlayer(AttackInfo monsterAttackPlayerInfo) {
        gameScreen.onMonsterAttackPlayer(monsterAttackPlayerInfo);
    }

    public void onMonsterInfo(MonsterInfo monsterInfo) {
        gameScreen.onMonsterInfo(monsterInfo);
    }

    public void onPlayerAttackMonster(AttackInfo playerAttackMonsterInfo) {
        gameScreen.onPlayerAttackMonster(playerAttackMonsterInfo);
    }

    public void onPlayerAttackPlayer(AttackInfo attackInfo) {
        gameScreen.onPlayerAttackPlayer(attackInfo);
    }

    /*
     * (non-Javadoc)
     * 
     * @see game.networklogic.IGameLogicHandler#onMap(byte)
     */
    public void onMap(byte map) {

    }

}
