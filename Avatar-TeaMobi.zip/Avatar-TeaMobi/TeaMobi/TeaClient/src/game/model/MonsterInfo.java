/**
 * 
 */
package game.model;

/**
 * @author Quynh Lam
 * 
 */
public class MonsterInfo {
    public short id, x, y, hp, maxhp, monster_type;
}
