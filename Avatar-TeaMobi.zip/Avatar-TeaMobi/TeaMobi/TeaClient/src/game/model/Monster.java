/**
 * 
 */
package game.model;

import game.render.Canvas;
import game.render.Res;

import javax.microedition.lcdui.Graphics;

/**
 * @author Quynh Lam
 * 
 */
public class Monster extends LiveActor {
    public static final String[] NAME = { "Nhen", "Nhen", "Heo" };
    public static final short[] SPEED = { 1, 2, 1 };
    public static final short[] HEIGHT = { 20, 20, 20 };
    public static final int STAND = 0;
    public static final int DEAD = 1;
    public static final int WALK = 2;
    public static final int ATTACK = 3;
    private static final short INJURE = 4;
    public static final int[][] monster_info = {//
    //
    { 16, 16, 8, 8 },//
    };//

    public short f, xTo, yTo, p1, p2, p3, state, monster_type, speed, z, dz;

    public void paint(Graphics g) {
        if (maxhp == 0)
            return;
        int realF = f + (dir << 2);
        g.drawRegion(Res.imgMonster[monster_type], 0, realF * monster_info[monster_type][1], monster_info[monster_type][0], monster_info[monster_type][1], 0, x - monster_info[monster_type][2], y - monster_info[monster_type][3] + z, 0);
    }

    public void jump() {
        z = -3;
        dz = -3;
    }

    public void paintHPBar(Graphics g) {
        if (maxhp == 0)
            return;
        int hpbLeft = x - 10;
        int hpbTop = y - height;
        int hpbWidth = 20;
        int hpbHeight = 3; // Include 2 pixel border
        g.setColor(0);
        g.fillRect(hpbLeft, hpbTop, hpbWidth, hpbHeight);
        g.setColor(0x33000);
        g.fillRect(hpbLeft + 1, hpbTop + 1, hpbWidth - 2, hpbHeight - 2);
        int hpInPixel = hp * (hpbWidth - 2) / maxhp;
        g.setColor(0xDD000);
        g.fillRect(hpbLeft + 1, hpbTop + 1, hpInPixel, hpbHeight - 2);
    }

    public void update() {
        if (realHPSyncTime > 0) {
            realHPSyncTime--;
            if (realHPSyncTime == 0) {
                if (realHP < 0)
                    realHP = 0;
                hp = realHP;
                if (hp == 0) {
                    state = INJURE;
                }
            }
        }
        if (z < 0) {
            z += dz;
            dz++;
            if (z > 0)
                z = 0;
        }
        switch (state) {
        case INJURE:
            f = 0;
            p1++;
            if (p1 == 5)
                Canvas.gameScr.startExplosionAt(x, y);
            if (p1 > 7) {
                wantDestroy = true;
            }
            break;
        case STAND:
            f = 0;
            break;
        case ATTACK:
            f = 2;
            p1++;
            if (p1 > 6) {
                p1 = 0;
                state = WALK;
            }
            break;
        case WALK:
            p1++;
            if (p1 > 6)
                p1 = 0;
            if (p1 > 2)
                f = 1;
            else
                f = 0;
            boolean isMatchX = false,
            isMatchY = false;
            int dx1 = Math.abs(x - xTo);
            int dy1 = Math.abs(y - yTo);

            if (dx1 <= speed) {
                x = xTo;
                isMatchX = true;
            }
            if (dy1 < speed) {
                y = yTo;
                isMatchY = true;
            }
            if (isMatchX && isMatchY) {
                p1 = p2 = p3 = 0;
                state = STAND;
                break;
            }
            if (x < xTo) {
                x += speed;
                dir = Char.RIGHT;
            } else if (x > xTo) {
                x -= speed;
                dir = Char.LEFT;
            } else if (y > yTo) {
                y -= speed;
                dir = Char.UP;
            } else if (y < yTo) {
                dir = Char.DOWN;
                y += speed;
            }
            break;
        }
    }

    public void setPosTo(short xTo, short yTo) {
        this.xTo = xTo;
        this.yTo = yTo;

        if (x == xTo && y == yTo)
            state = STAND;
        else
            state = WALK;
    }

    /**
     * @param monsterInfo
     */
    public void setInfo(MonsterInfo monsterInfo) {
        x = (monsterInfo.x );
        y = (monsterInfo.y );
        realHP = hp = monsterInfo.hp;
        maxhp = monsterInfo.maxhp;
        state = STAND;
        p1 = 0;
        p2 = 0;
        p3 = 0;
        monster_type = monsterInfo.monster_type;
        speed = SPEED[monster_type];
        name = NAME[monster_type];
        height = HEIGHT[monster_type];
    }

    /**
     * 
     */
    public void startAttack() {
        state = ATTACK;
        p1 = p2 = p3 = 0;

    }

    /**
     * 
     */
    public void startInjure() {
        p1 = p2 = p3 = 0;
        state = INJURE;
    }
}
