/**
 * 
 */
package game.model;

import javax.microedition.lcdui.Graphics;

/**
 * @author Quynh Lam
 * 
 */
public class CharShadow extends Actor {

    /*
     * (non-Javadoc)
     * 
     * @see game.model.Actor#paint(javax.microedition.lcdui.Graphics)
     */
    public void paint(Graphics g) {
        g.setColor(0xFF0000);
        g.fillRect(x - 1, y - 1, 2, 2);

    }

    /*
     * (non-Javadoc)
     * 
     * @see game.model.Actor#setPosTo(short, short)
     */
    public void setPosTo(short x, short y) {
        this.x = x;
        this.y = y;
    }

    /*
     * (non-Javadoc)
     * 
     * @see game.model.Actor#update()
     */
    public void update() {
        // TODO Auto-generated method stub

    }

}
