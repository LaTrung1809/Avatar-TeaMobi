/**
 * 
 */
package game.model;

/**
 * @author Quynh Lam
 * 
 */
public class CharInfo {
    public short id;
    public String name;
    public short x, y, hp, maxhp;
    public short skillID;

}
