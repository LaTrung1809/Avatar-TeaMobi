/**
 * 
 */
package game.model;

/**
 * @author Quynh Lam
 * 
 */
public abstract class LiveActor extends Actor {
    public short realHP, realHPSyncTime;
    public short hp;
    public short maxhp;
    public short dir;

    public void setRealHP(short realHP) {
        System.out.println("SET");
        this.realHP = realHP;
        realHPSyncTime = 20;
    }
}
