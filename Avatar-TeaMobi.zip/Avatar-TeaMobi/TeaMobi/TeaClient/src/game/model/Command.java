/**
 * 
 */
package game.model;

/**
 * @author Quynh Lam
 * 
 */
public class Command {

    public String caption;
    public IAction action;

    /**
     * @param caption
     * @param action
     */
    public Command(String caption, IAction action) {
        super();
        this.caption = caption;
        this.action = action;
    }
}
