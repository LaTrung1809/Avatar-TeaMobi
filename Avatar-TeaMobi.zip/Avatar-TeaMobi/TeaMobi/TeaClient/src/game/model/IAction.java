/**
 * 
 */
package game.model;

/**
 * @author Quynh Lam
 * 
 */
public interface IAction {
    public void perform();
}
