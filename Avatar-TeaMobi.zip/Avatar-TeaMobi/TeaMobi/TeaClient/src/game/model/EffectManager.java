/**
 * 
 */
package game.model;

import java.util.Vector;

import javax.microedition.lcdui.Graphics;

/**
 * @author Quynh Lam
 * 
 */
public class EffectManager extends Vector {
    public static EffectManager lowEffects = new EffectManager();
    public static EffectManager hiEffects = new EffectManager();

    public void updateAll() {
        for (int i = size() - 1; i >= 0; i--) {
            Effect e = (Effect) elementAt(i);
            e.update();
            if (e.wantDetroy)
                removeElementAt(i);

        }
    }

    public void paintAll(Graphics g) {
        for (int i = 0; i < size(); i++) {
            ((Effect) elementAt(i)).paint(g);
        }
    }
}
