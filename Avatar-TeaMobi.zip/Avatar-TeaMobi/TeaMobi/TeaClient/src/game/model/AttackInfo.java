/**
 * 
 */
package game.model;

/**
 * @author Quynh Lam
 * 
 */
public class AttackInfo {
    public short attacker, attacked, hpLost, hpLeft;
    public short skill;
}
