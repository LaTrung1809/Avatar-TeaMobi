/**
 * 
 */
package game.model;

import javax.microedition.lcdui.Graphics;

/**
 * @author Quynh Lam
 * 
 */
public abstract class Actor {
    public boolean wantDestroy;
    public String name;
    public short type;
    public short ID;
    public short x;
    public short y, height;
    public short centerX, centerY;

    public abstract void paint(Graphics g);

    public abstract void update();

    public abstract void setPosTo(short x, short y);
}
