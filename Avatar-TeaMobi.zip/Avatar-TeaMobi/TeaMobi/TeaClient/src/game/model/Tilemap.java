/**
 * 
 */
package game.model;

import game.render.Canvas;
import game.render.Res;

import java.io.InputStream;

import javax.microedition.lcdui.Graphics;

/**
 * @author Quynh Lam
 * 
 */
public class Tilemap {
    public static int w, h, pxw, pxh;
    public static final int T_BLOCK = 2;

    public static byte[] map;
    public static byte[] mapTop;
    public static int[] type;

    public static void loadMap(int level) {
        level = 0;
        if (level == 0) {
            w = 50;
            h = 50;
        }
        pxw = w << 4;
        pxh = h << 4;
        try {
            InputStream is = "".getClass().getResourceAsStream("/" + level + "g");
            map = new byte[w * h];
            mapTop = new byte[w * h];
            type = new int[w * h];
            for (int i = 0; i < w * h; i++) {
                map[i] = (byte) is.read();
                if (map[i] == 0 || map[i] == 1 || map[i] == 2 || map[i] == 43 || map[i] == 23 //
                        || map[i] == 70 || map[i] == 71 || map[i] == 72 || //
                        map[i] == 73 || map[i] == 74 || map[i] == 75//
                        || map[i] == 59 || map[i] == 60 || map[i] == 46 || map[i] == 45//
                        || map[i] == 33 || map[i] == 18 || map[i] == 17)
                    type[i] = T_BLOCK;
            }
            is = "".getClass().getResourceAsStream("/" + level + "h");
            for (int i = 0; i < w * h; i++) {
                mapTop[i] = (byte) is.read();
            }
        } catch (Exception e) {
            System.out.println("LOAD TILE ERR");
        }

    }

    public static final void paintTile(Graphics g) {
        for (int a = Canvas.gameScr.gssx; a < Canvas.gameScr.gssxe; a++) {
            for (int b = Canvas.gameScr.gssy; b < Canvas.gameScr.gssye; b++) {
                int t = map[b * w + a] - 1;
                if (t != -1)
                    g.drawRegion(Res.imgTile, 0, t << 4, 16, 16, 0, a << 4, b << 4, 0);
            }
        }
    }

    public static void paintTileTop(Graphics g) {
        for (int a = Canvas.gameScr.gssx; a < Canvas.gameScr.gssxe; a++) {
            for (int b = Canvas.gameScr.gssy; b < Canvas.gameScr.gssye; b++) {
                int t = mapTop[b * w + a] - 1;
                if (t != -1)
                    g.drawRegion(Res.imgTile, 0, t << 4, 16, 16, 0, a << 4, b << 4, 0);
            }
        }

    }

    public static final int tileAt(int x, int y) {
        return map[y * w + x];
    }

    public static final int tileTypeAt(int x, int y) {
        return type[y * w + x];
    }

    public static final int tileTypeAtPixel(int px, int py) {
        return type[(py >> 4) * w + (px >> 4)];
    }

    public static final boolean tileTypeAtPixel(int px, int py, int t) {
        return (type[(py >> 4) * w + (px >> 4)] & t) == t;
    }

    public static final boolean tileTypeAt(int x, int y, int t) {
        return (type[y * w + x] & t) == t;
    }

    public static final void setTileTypeAt(int px, int py, int t) {
        type[(py >> 4) * w + (px >> 4)] |= t;
    }

    public static final void setTileAt(int x, int y, byte t) {
        map[y * w + x] = t;
        type[y * w + x] = 0;
    }

    public static final void killTileTypeAt(int px, int py, int t) {
        type[(py >> 4) * w + (px >> 4)] &= ~t;
    }

    public static final int tileYofPixel(int py) {
        return (py >> 4) << 4;
    }

    public static final int tileXofPixel(int px) {
        return (px >> 4) << 4;
    }

}
