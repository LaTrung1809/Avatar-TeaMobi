/**
 * 
 */
package game.model;

/**
 * @author Quynh Lam
 * 
 */
public class ActorFactory {
    public static Actor CreateActor(short type, short id, short x, short y) {
        Actor a = null;

        switch (type) {
        case 0:
            a = new Char();
            break;
        case 1:
            a = new Monster();
            break;
        case 2:
            a = new Item();
            break;
        default:
            break;
        }
        a.x = x;
        a.y = y;
        a.type = type;
        a.ID = id;
        return a;
    }
}
