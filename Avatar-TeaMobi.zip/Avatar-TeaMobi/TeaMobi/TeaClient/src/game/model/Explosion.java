/**
 * 
 */
package game.model;

import game.render.Res;

import javax.microedition.lcdui.Graphics;

/**
 * @author Quynh Lam
 * 
 */
public class Explosion extends Actor {

    int f = 0;
    int p1;

    public Explosion(short x, short y) {
        type = 1000;
        this.x = x;
        this.y = y;
        p1 = 0;
    }

    public void paint(Graphics g) {
        g.drawRegion(Res.imgExplosion, 0, f * 24, 24, 24, 0, x - 12, y - 24, 0);

    }

    /*
     * (non-Javadoc)
     * 
     * @see game.model.Actor#setPosTo(short, short)
     */
    public void setPosTo(short x, short y) {
        this.x = x;
        this.y = y;

    }

    /*
     * (non-Javadoc)
     * 
     * @see game.model.Actor#update()
     */
    public void update() {
        p1++;
        if (p1 > 8) {
            p1 = 0;
            wantDestroy = true;
        }
        f = p1 >> 1;
    }

}
