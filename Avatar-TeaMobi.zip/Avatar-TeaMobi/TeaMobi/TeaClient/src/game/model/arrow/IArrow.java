/**
 * 
 */
package game.model.arrow;

import game.model.LiveActor;

import javax.microedition.lcdui.Graphics;

/**
 * @author Quynh Lam
 * 
 */
public interface IArrow {

    public abstract void set(int type, int x, int y, int power, LiveActor owner, LiveActor target);

    public abstract void update();

    public abstract void paint(Graphics g);

    public void onArrowTouchTarget();

}