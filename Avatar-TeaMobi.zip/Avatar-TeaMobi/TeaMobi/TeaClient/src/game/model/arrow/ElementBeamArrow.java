/**
 * 
 */
package game.model.arrow;

import javax.microedition.lcdui.Graphics;

/**
 * @author Quynh Lam
 * 
 */
public class ElementBeamArrow extends Arrow {

    public void onArrowTouchTarget() {
        super.onArrowTouchTarget();
    }

    public void paint(Graphics g) {
        super.paint(g);
    }

    public void update() {
        super.update();
    }

}
