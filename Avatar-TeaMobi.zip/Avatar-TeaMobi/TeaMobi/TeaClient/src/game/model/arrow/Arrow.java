/**
 * 
 */
package game.model.arrow;

import game.Util;
import game.model.Effect;
import game.model.EffectManager;
import game.model.LiveActor;
import game.model.Monster;
import game.render.Canvas;

import javax.microedition.lcdui.Graphics;

/**
 * @author Quynh Lam
 * 
 */
public class Arrow implements IArrow {
    public int power;
    public int type;
    public int angle;
    public short va;

    public int x, y, z, frame; // object position
    public int w, h; // object size
    public int vx, vy; // van toc theo phuong x, phuong y
    int life;
    LiveActor target;
    LiveActor owner;
    public boolean wantDestroy;
    public static final short SPEED[] = { 0, 16, 8, 8, 12, 16 };

    public void set(int type, int x, int y, int power, LiveActor owner, LiveActor target) {
        this.x = x;
        this.y = y;
        this.type = type;
        this.owner = owner;
        this.target = target;
        switch (owner.dir) {
        case 0:
            angle = 90;
            break;
        case 1:
            angle = 270;
            break;
        case 2:
            angle = 180;
            break;
        case 3:
            angle = 0;
            break;
        }

        va = (short) (1024 * SPEED[type]);
        z = 0;
        life = 0;
        this.power = power;
        vx = (va * Util.cos(angle)) >> 10;
        vy = (va * Util.sin(angle)) >> 10;
    }

    public void update() {
        int dx, dy;
        int a;
        dx = target.x - x;
        dy = target.y - (target.height >> 1) - y;
        life++;
        if ((Util.abs(dx) < 16 && Util.abs(dy) < 16) || life > 30) {
            onArrowTouchTarget();
            return;
        }
        a = Util.angle(dx, dy);

        if (Math.abs(a - angle) < 90 || dx * dx + dy * dy > 64 * 64) {
            if (Math.abs(a - angle) < 15)
                angle = a;
            else if (a - angle >= 0 && a - angle < 180 || a - angle < -180)
                angle = Util.fixangle(angle + 15);
            else
                angle = Util.fixangle(angle - 15);
        }
        if (va < 8 << 10)
            va += 1024;
        vx = (va * Util.cos(angle)) >> 10;
        vy = (va * Util.sin(angle)) >> 10;
        //
        dx += vx;
        x += dx >> 10;
        dx = dx & 0x3ff;
        dy += vy;
        y += dy >> 10;
        dy = dy & 0x3ff;
        switch (type) {
        case 0: // Hoa
            EffectManager.hiEffects.addElement(new Effect(x, y, 1));
            break;
        case 1: // Kim
            EffectManager.hiEffects.addElement(new Effect(x, y, 2));
            break;
        case 2: // Tho
            EffectManager.hiEffects.addElement(new Effect(x, y, 4));
            break;
        case 3: // Thuy
            EffectManager.hiEffects.addElement(new Effect(x, y, 6));
            break;
        case 4: // Moc
            EffectManager.hiEffects.addElement(new Effect(x, y, 8));
            break;
        default:
            break;
        }

    }

    /**
     * 
     */
    public void onArrowTouchTarget() {
        switch (type) {
        case 0: // Hoa
            Canvas.gameScr.startExplosionAt(target.x, target.y);
            break;
        case 1: // Kim
            EffectManager.hiEffects.addElement(new Effect(target.x, target.y - 10, 3));
            break;
        case 2: // Tho
            EffectManager.hiEffects.addElement(new Effect(target.x, target.y - 10, 5));
            break;
        case 3: // Thuy
            EffectManager.hiEffects.addElement(new Effect(target.x, target.y - 10, 7));
            break;
        case 4: // Moc
            EffectManager.hiEffects.addElement(new Effect(target.x, target.y - 10, 9));
            break;
        default:
            break;
        }
        target.realHPSyncTime = 2;
        if (target.type == 1) {
            ((Monster) target).jump();
        }
        wantDestroy = true;
    }

    public void paint(Graphics g) {

    }
}
