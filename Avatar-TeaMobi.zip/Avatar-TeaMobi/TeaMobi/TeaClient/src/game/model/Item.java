/**
 * 
 */
package game.model;

import javax.microedition.lcdui.Graphics;

/**
 * @author Quynh Lam
 * 
 */
public class Item extends Actor {

    /*
     * (non-Javadoc)
     * 
     * @see game.model.Actor#paint(javax.microedition.lcdui.Graphics)
     */
    public void paint(Graphics g) {
        // TODO Auto-generated method stub

    }

    /*
     * (non-Javadoc)
     * 
     * @see game.model.Actor#update()
     */
    public void update() {
        // TODO Auto-generated method stub

    }

    /*
     * (non-Javadoc)
     * 
     * @see game.model.Actor#setPosTo()
     */
    public void setPosTo(short x, short y) {
        // TODO Auto-generated method stub

    }

}
