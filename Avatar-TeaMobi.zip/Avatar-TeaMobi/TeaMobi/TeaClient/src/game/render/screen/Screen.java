/**
 * 
 */
package game.render.screen;

import game.render.Canvas;

import javax.microedition.lcdui.Graphics;

/**
 * @author Quynh Lam
 * 
 */
public abstract class Screen {
    public void switchToMe() {
        Canvas.currentScreen = this;
        Canvas.instance.setFullScreenMode(true);
    }

    public abstract void paint(Graphics g);

    public abstract void update();
}
