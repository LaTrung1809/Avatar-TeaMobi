/**
 * 
 */
package game.render.screen;

import game.model.Command;
import game.render.Canvas;
import game.render.Font;

import javax.microedition.lcdui.Graphics;

/**
 * @author Quynh Lam
 * 
 */
public class MessageScr extends Screen {

    protected String[] info;
    public Command left, center, right;

    public void setInfo(String info, Command left, Command center, Command right) {
        this.info = Font.splitFontBStrInLine(info, Canvas.w - 20);
        this.left = left;
        this.center = center;
        this.right = right;
    }

    public void paint(Graphics g) {
        g.setColor(0);
        g.fillRect(0, 0, Canvas.w, Canvas.h);
        int yStart = Canvas.hh - ((info.length >> 1) * Font.chB);
        for (int i = 0, y = yStart; i < info.length; i++) {
            Font.drawFontBString(g, info[i], Canvas.hw, y, 2);

        }
        if (left != null) {
            Font.drawFontBString(g, left.caption, 5, Canvas.h - Font.chB - 10, 0);
        }
        if (center != null) {
            Font.drawFontBString(g, center.caption, Canvas.hw, Canvas.h - Font.chB - 10, 2);
        }
        if (right != null) {
            Font.drawFontBString(g, right.caption, Canvas.w - 5, Canvas.h - Font.chB - 10, 1);
        }
    }

    public void update() {
        if (Canvas.keyPressed[5]) {
            Canvas.keyPressed[5] = false;
            if (center != null && center.action != null)
                center.action.perform();
        }
        if (Canvas.keyPressed[12]) {
            Canvas.keyPressed[12] = false;
            if (left != null && left.action != null)
                center.action.perform();
        }
        if (Canvas.keyPressed[13]) {
            Canvas.keyPressed[13] = false;
            if (right != null && right.action != null)
                right.action.perform();
        }
    }

}
