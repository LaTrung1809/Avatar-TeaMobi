/**
 * 
 */
package game.render.screen;

import game.render.Canvas;
import game.render.Font;

import javax.microedition.lcdui.Graphics;

/**
 * @author Quynh Lam
 * 
 */
public class WaitScr extends Screen {
    public String[] info;
    String[] loadText = { ".Please Wait.", "..Please Wait..", "...Please Wait...", "..Please Wait..", "Please Wait" };
    int loadTextPos;

    public void setInfo(String info) {
        System.out.println("info=" + info);
        this.info = Font.splitFontBStrInLine(info, Canvas.w - 20);
    }

    public void paint(Graphics g) {
        g.setColor(0);
        g.fillRect(0, 0, Canvas.w, Canvas.h);
        int yStart = Canvas.hh - ((info.length >> 1) * Font.chB);
        for (int i = 0, y = yStart; i < info.length; i++) {
            Font.drawFontBString(g, info[i], Canvas.hw, y, 2);
        }
        Font.drawFontBString(g, loadText[loadTextPos], Canvas.hw, Canvas.h - Font.chB - 10, 2);
    }

    public void update() {
        loadTextPos++;
        if (loadTextPos > 4)
            loadTextPos = 0;

    }

}
