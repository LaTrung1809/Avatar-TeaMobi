/**
 * 
 */
package game.render;

import java.util.Vector;

import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

/**
 * @author Quynh Lam
 * 
 */
public class Font {
    public static final int LEFT = 0;
    public static final int RIGHT = 1;
    public static final int CENTER = 2;
    private static Image imgFontB;
    private static final String stMapB = " 0123456789.,:!?()+-*/#$%abcdefghijklmnopqrstuvwxyzáàảãạăắằẳẵặâấầẩẫậéèẻẽẹêếềểễệíìỉĩịóòỏõọôốồổỗộơớờởỡợúùủũụưứừửữựýỳỷỹỵđABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final int[] cwB = { 3, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 4, 3, 3, 3, 6, 7, 7, 8, 5, 11, 11, 7, 6, 10, 6, 7, 5, 7, 6, 5, 7, 7, 3, 3, 6, 3, 9, 7, 7, 7, 7, 4, 5, 4, 8, 6, 9, 7, 6, 5, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 8, 7, 8, 7, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 4, 3, 3, 3, 3, 7, 7, 7, 7, 7, 7, 7, 7, 8, 7, 7, 7, 8, 7, 8, 8, 8, 7, 7, 8, 7, 6, 7, 8, 8, 8, 8, 8, 6, 6, 6, 6, 6, 7, 8, 7, 7, 8, 6, 6, 8, 8, 3, 6, 7, 6, 11, 9, 8, 7, 8, 7, 5, 6, 8, 7, 11, 7, 7, 7, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 6, 6, 6, 6, 6, 6, 7, 6, 6, 6, 6, 5, 5, 5, 6, 5, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 10, 10, 10, 10, 10, 10, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 9, 7, 7, 7, 7, 7, 9, };
    public static int chB = 13;
    static {
        try {
            imgFontB = Image.createImage("/fb.png");
        } catch (Exception e) {
        }
    }

    public static void drawFontBString(Graphics g, String st, int x, int y, int align) {
        int pos;
        int x1;
        int len = st.length();
        if (align == 0)
            x1 = x;
        else if (align == 1)
            x1 = x - getFontBWidthOf(st);
        else
            x1 = x - (getFontBWidthOf(st) >> 1);
        for (int i = 0; i < len; i++) {
            pos = stMapB.indexOf(st.charAt(i));
            if (pos == -1)
                pos = 0;
            if (pos > -1)
                g.drawRegion(imgFontB, 0, pos * chB + 1, cwB[pos], chB - 1, 0, x1, y, 20);
            x1 += cwB[pos];
        }
    }

    public static int getFontBWidthOf(String st) {
        int pos;
        int len = 0;
        for (int i = 0; i < st.length(); i++) {
            pos = stMapB.indexOf(st.charAt(i));
            if (pos == -1)
                pos = 0;
            len += (cwB[pos]);
        }
        return len;
    }

    public static String[] splitFontBStrInLine(String src, int lineWidth) {
        Vector list = new Vector();
        int srclen = src.length();
        if (srclen <= 1)
            return new String[] { src };
        String tem = "";
        int start = 0, end = 0;
        while (true) {
            while (getFontBWidthOf(tem) < lineWidth) {
                tem += src.charAt(end);
                end++;
                if (src.charAt(end) == '\n')
                    break;
                if (end >= srclen - 1) {
                    end = srclen - 1;
                    break;
                }
            }
            if (end != srclen - 1 && (src.charAt(end + 1) != ' ')) {
                int endAnyway = end;
                while (true) {
                    if (src.charAt(end + 1) == '\n')
                        break;
                    if (src.charAt(end + 1) == ' ' && src.charAt(end) != ' ')
                        break;
                    if (end == start)
                        break;
                    end--;
                }
                if (end == start)
                    end = endAnyway;
            }
            list.addElement(src.substring(start, end + 1));
            if (end == srclen - 1)
                break;
            start = end + 1;
            while (start != srclen - 1 && src.charAt(start) == ' ')
                start++;
            if (start == srclen - 1)
                break;
            end = start;
            tem = "";
        }
        String[] strs = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            strs[i] = (String) list.elementAt(i);
        }
        return strs;
    }

}
