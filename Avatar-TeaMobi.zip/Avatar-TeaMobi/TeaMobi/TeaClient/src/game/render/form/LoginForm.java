/**
 * 
 */
package game.render.form;

import game.GameMidlet;
import game.networklogic.GameService;
import game.render.Canvas;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.TextField;


import network.Session_ME;

/**
 * @author Quynh Lam
 * 
 */
public class LoginForm extends Form implements CommandListener {
    TextField tfUser, tfPass, tfMap;

    public LoginForm() {
        super("Login");
        tfUser = new TextField("Username", "", 20, 0);
        tfPass = new TextField("Pass", "", 20, TextField.PASSWORD);
        tfMap = new TextField("Map", "0", 20, TextField.NUMERIC);
        append(tfUser);
        append(tfPass);
        append(tfMap);
        addCommand(new Command("Login", 3, 0));
        addCommand(new Command("Exit", 4, 0));
        setCommandListener(this);
    }

    public void commandAction(Command c, Displayable arg1) {
        if (c.getLabel().equals("Login"))
            doLogin();
        else
            GameMidlet.instance.notifyDestroyed();
    }

    private void doLogin() {
        if (tfUser.getString().equals("") || tfPass.getString().equals(""))
            return;
        Display.getDisplay(GameMidlet.instance).setCurrent(Canvas.instance);
        Canvas.waitScr.setInfo("Connecting...");
        Canvas.waitScr.switchToMe();
        Session_ME.gI().connect(GameMidlet.IP, GameMidlet.PORT);
        GameService.gI().login(tfUser.getString(), tfPass.getString(), Byte.parseByte(tfMap.getString()));
    }
}
