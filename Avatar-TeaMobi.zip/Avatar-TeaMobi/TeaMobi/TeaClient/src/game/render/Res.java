/**
 * 
 */
package game.render;

import javax.microedition.lcdui.Image;

/**
 * @author Quynh Lam
 * 
 */
public class Res {
    public static Image imgCharLeg[], imgCharBody[], imgCharHead[], imgCharHat[];
    public static Image imgTile, imgSelect;
    public static Image imgEffect[] = new Image[50];
    public static Image imgMonster[] = new Image[50];
    public static Image imgSkill[] = new Image[50];;
    // skillInfo[ID{0,1,2...}][dir{0,1,2,3}][AttackFrame{0,1,2,3}][WeaponInfo{x0,y0,w,h,dxwithChar,dyWithChar}]
    public static int skillInfo[][][][] = {//

    { // Begin skill axe down
    //  
            // Down
            { { 6, 5, 2, 13, -6, -32 }, { 6, 5, 2, 13, -6, -32 }, { 0, 0, 5, 43, -6, -29 }, { 0, 25, 5, 18, -6, -3 } },
            // Up
            { { 6, 0, 2, 18, 7, -36 }, { 6, 0, 2, 18, 7, -36 }, { 6, 22, 2, 21, 3, -44 }, { 0, 0, 0, 0, 0, 0 } },
            // Left
            { { 29, 0, 20, 13, -7, -35 }, { 29, 0, 20, 13, -8, -34 }, { 8, 13, 24, 34, -30, -30 }, { 8, 33, 20, 14, -30, -10 } },
            // Right
            { { 8, 0, 20, 13, -13, -35 }, { 8, 0, 20, 13, -11, -34 }, { 29, 13, 24, 34, 6, -30 }, { 29, 33, 24, 14, 6, -10 } },
    //
    } // End Skill Axe Down

    };
    public static Image imgExplosion;

    public static void loadSkill(int skillID) {
        if (imgSkill[skillID] == null) {
            try {
                imgSkill[skillID] = Image.createImage("/skill/sk" + skillID + ".png");
            } catch (Exception e) {
                System.out.println("Error Load Skill " + skillID);
            }
        }
    }

    public static void loadEffect(int type) {
        if (imgEffect[type] == null) {
            try {
                imgEffect[type] = Image.createImage("/eff/g" + type + ".png");
            } catch (Exception e) {
                System.out.println("Error Load Effetc " + type);
            }
        }
    }

    public static void loadMonster(int monster_type) {
        if (imgMonster[monster_type] == null) {
            try {
                imgMonster[monster_type] = Image.createImage("/m/m" + monster_type + ".png");
            } catch (Exception e) {
                System.out.println("Error Load Monster " + monster_type);
            }
        }
    }

    public static void loadExplosionImage() {
        if (imgExplosion == null) {
            try {
                imgExplosion = Image.createImage("/eff/explosion.png");
            } catch (Exception e) {
                System.out.println("Error Load Expl");
            }
        }
    }

    public static void loadCharImage() {
        try {
            imgCharBody = new Image[3];
            imgCharLeg = new Image[3];
            imgCharHead = new Image[3];
            imgCharHat = new Image[3];
            for (int i = 0; i < 3; i++) {
                imgCharBody[i] = Image.createImage("/body_g_" + i + ".png");
                imgCharLeg[i] = Image.createImage("/leg_g_" + i + ".png");
                imgCharHead[i] = Image.createImage("/head_g_" + i + ".png");
                imgCharHat[i] = Image.createImage("/hat_g_" + i + ".png");
            }
        } catch (Exception e) {
            System.out.println("Error Load Char");
        }
    }

    public static void loadImgSel() {
        try {
            imgSelect = Image.createImage("/select.png");
        } catch (Exception e) {
        }
    }

    public static final void loadTileImage() {
        if (imgTile == null) {
            try {
                imgTile = Image.createImage("/t.png");
            } catch (Exception e) {
                System.out.println("Error Load Back Tile");
            }
        }
    }
}
