package game.networklogic;

public class Cmd_Client2Server {
    public static final short LOGIN = 1;
    public static final short LOGOUT = 2;
    public static final short CHAT_TO = 3;
    public static final short MOVE_CHAR = 4;
    public static final short REQUEST_CHAR_INFO = 5;
    public static final short ATTACK_PLAYER = 6;
    public static final short REQUEST_MONSTER_INFO = 7;
    public static final short ATTACK_MONSTER = 9;
    public static final int PING = 11;
}
