/**
 * 
 */
package game.networklogic;

import java.io.IOException;

import network.ISession;
import network.Message;

/**
 * @author Quynh Lam
 * 
 */
public class GameService {
    ISession session;

    protected static GameService instance;

    public static GameService gI() {
        if (instance == null)
            instance = new GameService();
        return instance;
    }

    public void login(String username, String pass, byte mapID) {
        Message m = new Message(2, Cmd_Client2Server.LOGIN);
        try {
            m.getDataOutputStream().writeUTF(username);
            m.getDataOutputStream().writeUTF(pass);
            m.getDataOutputStream().writeByte(mapID);
            session.sendMessage(m);
            m.cleanup();
        } catch (IOException e) {
        }
    }

    public void logout() {
        Message m = new Message(2, Cmd_Client2Server.LOGOUT);
        session.sendMessage(m);
        m.cleanup();
    }

    public void moveChar(int x, int y) {
        Message m = new Message(2, Cmd_Client2Server.MOVE_CHAR);
        try {
            m.getDataOutputStream().writeShort(x);
            m.getDataOutputStream().writeShort(y);
        } catch (Exception e) {
        }
        session.sendMessage(m);
        m.cleanup();
    }

    public void requestCharInfo(short actorID) {
        Message m = new Message(2, Cmd_Client2Server.REQUEST_CHAR_INFO);
        try {
            m.getDataOutputStream().writeShort(actorID);
        } catch (Exception e) {
        }
        session.sendMessage(m);
        m.cleanup();
    }

    /**
     * @param id
     * @param i
     */
    public void attackMonster(short id, short skill) {
        Message m = new Message(2, Cmd_Client2Server.ATTACK_MONSTER);
        try {
            m.getDataOutputStream().writeShort(id);
            m.getDataOutputStream().writeShort(skill);
        } catch (Exception e) {
        }
        session.sendMessage(m);
        m.cleanup();

    }

    public void attackOtherPlayer(short id, short skill) {
        Message m = new Message(2, Cmd_Client2Server.ATTACK_PLAYER);
        try {
            m.getDataOutputStream().writeShort(id);
            m.getDataOutputStream().writeShort(skill);
        } catch (Exception e) {
        }
        session.sendMessage(m);
        m.cleanup();

    }

    /**
     * @param actorID
     */
    public void requestMonsterInfo(short actorID) {
        Message m = new Message(2, Cmd_Client2Server.REQUEST_MONSTER_INFO);
        try {
            m.getDataOutputStream().writeShort(actorID);
        } catch (Exception e) {
        }
        session.sendMessage(m);
        m.cleanup();

    }

    /**
     * 
     */
    public void ping() {
        Message m = new Message(2, Cmd_Client2Server.PING);
        session.sendMessage(m);
        m.cleanup();
    }

    /**
     * @param gi
     */
    public void setSession(ISession gi) {
        this.session = gi;
    }
}
