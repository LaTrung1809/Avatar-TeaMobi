/**
 * 
 */
package game.networklogic;

/**
 * @author Quynh Lam
 * 
 */
public class Cmd_Server2Client {
    public static final short LOGIN_SUCESS = 1;
    public static final short LOGIN_FAIL = 2;
    public static final short INFO_MAIN_CHAR = 3;
    public static final short INFO_ACTOR_POS = 4;
    public static final short INFO_CHAR = 5;
    public static final short PLAYER_ATTACK_PLAYER = 6;
    public static final short MONSTER_INFO = 7;
    public static final short CHAR_OUT = 8;
    public static final short PLAYER_ATTACK_MONSTER = 9;
    public static final short MONSTER_ATTACK_PLAYER = 10;
    public static final int PING = 11;
    public static final int CHANGE_MAP = 12;
}
