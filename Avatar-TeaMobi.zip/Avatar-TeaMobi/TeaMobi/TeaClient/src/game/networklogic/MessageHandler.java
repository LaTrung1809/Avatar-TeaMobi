package game.networklogic;

import game.model.AttackInfo;
import game.model.CharInfo;
import game.model.MonsterInfo;
import game.render.Canvas;
import network.IMessageHandler;
import network.Message;

public class MessageHandler implements IMessageHandler {

    IGameLogicHandler gameLogicHandler;

    protected static MessageHandler instance;

    public static MessageHandler gI() {
        if (instance == null)
            instance = new MessageHandler();
        return instance;
    }

    public void onConnectOK() {
        gameLogicHandler.onConnectOK();
    }

    public void onConnectionFail() {
        gameLogicHandler.onConnectFail();
    }

    public void onDisconnected() {
        gameLogicHandler.onDisconnect();
    }

    public void onMessage(Message message) {
        try {
            switch (message.command) {
            case Cmd_Server2Client.LOGIN_SUCESS:
                gameLogicHandler.onLoginSuccess();
                break;
            case Cmd_Server2Client.INFO_MAIN_CHAR:
                CharInfo mainCharInfo = new CharInfo();
                mainCharInfo.id = message.getDataInputStream().readShort();
                mainCharInfo.name = message.getDataInputStream().readUTF();
                mainCharInfo.x = message.getDataInputStream().readShort();
                mainCharInfo.y = message.getDataInputStream().readShort();
                mainCharInfo.hp = message.getDataInputStream().readShort();
                mainCharInfo.maxhp = message.getDataInputStream().readShort();
                mainCharInfo.skillID = 0;
                gameLogicHandler.onInfoMainChar(mainCharInfo);
                break;
            case Cmd_Server2Client.CHANGE_MAP:
                byte map = message.getDataInputStream().readByte();
                gameLogicHandler.onMap(map);
            case Cmd_Server2Client.INFO_ACTOR_POS:
                while (message.getDataInputStream().available() > 0) {
                    short actorType = message.getDataInputStream().readShort();
                    short actorID = message.getDataInputStream().readShort();
                    short x2 = message.getDataInputStream().readShort();
                    short y2 = message.getDataInputStream().readShort();
                    gameLogicHandler.onActorMove(actorType, actorID, x2, y2);
                }
                break;
            case Cmd_Server2Client.CHAR_OUT:
                short charID = message.getDataInputStream().readShort();
                gameLogicHandler.charOutGame(charID);
                System.out.println("CHAR " + charID + " has out game");
                break;
            case Cmd_Server2Client.INFO_CHAR:
                CharInfo charInfo = new CharInfo();
                charInfo.id = message.getDataInputStream().readShort();
                charInfo.name = message.getDataInputStream().readUTF();
                charInfo.x = message.getDataInputStream().readShort();
                charInfo.y = message.getDataInputStream().readShort();
                charInfo.hp = message.getDataInputStream().readShort();
                charInfo.maxhp = message.getDataInputStream().readShort();
                gameLogicHandler.onCharInfo(charInfo);
                break;
            case Cmd_Server2Client.MONSTER_INFO:
                MonsterInfo monsterInfo = new MonsterInfo();
                monsterInfo.id = message.getDataInputStream().readShort();
                monsterInfo.monster_type = message.getDataInputStream().readShort();
                monsterInfo.x = message.getDataInputStream().readShort();
                monsterInfo.y = message.getDataInputStream().readShort();
                monsterInfo.hp = message.getDataInputStream().readShort();
                monsterInfo.maxhp = message.getDataInputStream().readShort();
                gameLogicHandler.onMonsterInfo(monsterInfo);
                break;
            case Cmd_Server2Client.PLAYER_ATTACK_PLAYER:
                AttackInfo attackInfo = new AttackInfo();
                attackInfo.attacker = message.getDataInputStream().readShort();
                attackInfo.attacked = message.getDataInputStream().readShort();
                attackInfo.skill = message.getDataInputStream().readShort();
                attackInfo.hpLost = message.getDataInputStream().readShort();
                attackInfo.hpLeft = message.getDataInputStream().readShort();
                gameLogicHandler.onPlayerAttackPlayer(attackInfo);
                break;
            case Cmd_Server2Client.PLAYER_ATTACK_MONSTER:
                AttackInfo playerAttackMonsterInfo = new AttackInfo();
                playerAttackMonsterInfo.attacker = message.getDataInputStream().readShort();
                playerAttackMonsterInfo.attacked = message.getDataInputStream().readShort();
                playerAttackMonsterInfo.skill = message.getDataInputStream().readShort();
                playerAttackMonsterInfo.hpLost = message.getDataInputStream().readShort();
                playerAttackMonsterInfo.hpLeft = message.getDataInputStream().readShort();
                gameLogicHandler.onPlayerAttackMonster(playerAttackMonsterInfo);
                break;
            case Cmd_Server2Client.MONSTER_ATTACK_PLAYER:
                AttackInfo monsterAttackPlayerInfo = new AttackInfo();
                monsterAttackPlayerInfo.attacker = message.getDataInputStream().readShort();
                monsterAttackPlayerInfo.attacked = message.getDataInputStream().readShort();
                monsterAttackPlayerInfo.hpLost = message.getDataInputStream().readShort();
                monsterAttackPlayerInfo.hpLeft = message.getDataInputStream().readShort();
                gameLogicHandler.onMonsterAttackPlayer(monsterAttackPlayerInfo);
                break;
            case Cmd_Server2Client.PING:
                Canvas.gameScr.onPingBack();
                break;

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @param gameLogicHandler
     *            the gameLogicHandler to set
     */
    public void setGameLogicHandler(IGameLogicHandler gameLogicHandler) {
        this.gameLogicHandler = gameLogicHandler;
    }

}
