/**
 * 
 */
package game.networklogic;

import game.model.AttackInfo;
import game.model.CharInfo;
import game.model.MonsterInfo;

/**
 * @author Quynh Lam
 * 
 */
public interface IGameLogicHandler {

    public void onMonsterAttackPlayer(AttackInfo monsterAttackPlayerInfo);

    public void onPlayerAttackMonster(AttackInfo playerAttackMonsterInfo);

    public void onPlayerAttackPlayer(AttackInfo attackInfo);

    public void onMonsterInfo(MonsterInfo monsterInfo);

    public void onCharInfo(CharInfo charInfo);

    public void charOutGame(short charID);

    public void onActorMove(short actorType, short actorID, short x2, short y2);

    public void onInfoMainChar(CharInfo mainCharInfo);

    public void onMap(byte map);

    public void onLoginSuccess();

    public void onConnectOK();

    public void onConnectFail();

    public void onDisconnect();
}
