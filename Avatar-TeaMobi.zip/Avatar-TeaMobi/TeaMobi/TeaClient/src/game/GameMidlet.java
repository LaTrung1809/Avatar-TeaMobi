/**
 * 
 */
package game;

import game.networklogic.MessageHandler;
import game.render.Canvas;
import game.render.Res;
import game.render.form.LoginForm;

import javax.microedition.lcdui.Display;
import javax.microedition.midlet.MIDletStateChangeException;

import network.Session_ME;

/**
 * @author Quynh Lam
 * 
 */
public class GameMidlet extends javax.microedition.midlet.MIDlet {
    // public static final String IP = "210.245.115.227";
    public static final String IP = "112.78.1.106";
    // public static final String IP = "127.0.0.1";
    // public static final String IP = "5.54.51.101";
    public static final int PORT = 9123;
    public static LoginForm loginForm;
    public static Canvas gameCanvas;
    public static GameMidlet instance;

    public GameMidlet() {

        instance = this;

        loginForm = new LoginForm();
        gameCanvas = new Canvas();
        gameCanvas.start();
        //
        MessageHandler.gI().setGameLogicHandler(Canvas.gameScr);
        Session_ME.gI().setHandler(MessageHandler.gI());
        game.networklogic.GameService.gI().setSession(Session_ME.gI());
        //
        Display.getDisplay(this).setCurrent(loginForm);
        Res.loadCharImage();
        Res.loadTileImage();
        Res.loadImgSel();
        Res.loadMonster(0);
        Res.loadSkill(0);
        for (int i = 0; i < 10; i++)
            Res.loadEffect(i);
        Res.loadExplosionImage();
        // Tilemap.loadMap(0);
        // Canvas.gameScr.mainChar.x = 200;
        // Canvas.gameScr.mainChar.y = 200;
        // Canvas.gameScr.mainChar.name = "lam";
        // Canvas.gameScr.loadCamera();
        // Canvas.currentScreen = Canvas.gameScr;
        // Display.getDisplay(instance).setCurrent(gameCanvas);
    }

    protected void destroyApp(boolean arg0) throws MIDletStateChangeException {

    }

    protected void pauseApp() {

    }

    protected void startApp() throws MIDletStateChangeException {

    }

}
