/**
 * 
 */
package network;

/**
 * @author Quynh Lam
 *
 */
public interface ISession {

    public abstract boolean isConnected();

    public abstract void setHandler(IMessageHandler messageHandler);

    public abstract void connect(String host, int port);

    public abstract void sendMessage(Message message);

    public abstract void close();

}