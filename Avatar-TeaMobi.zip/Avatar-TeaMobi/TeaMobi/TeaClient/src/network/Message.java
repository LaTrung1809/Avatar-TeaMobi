package network;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Message {
    public int type;
    public int command;
    private ByteArrayOutputStream os = null;
    private DataOutputStream dos = null;
    private ByteArrayInputStream is = null;
    private DataInputStream dis = null;

    public Message() {
        type = 2;
    }

    public Message(int type, int command) {
        this.type = type;
        this.command = command;
    }

    Message(int type, int command, byte[] data) {
        this.type = type;
        this.command = command;
        is = new ByteArrayInputStream(data);
        dis = new DataInputStream(is);
    }

    public byte[] getData() {
        if (os != null)
            return os.toByteArray();
        return null;
    }

    public DataInputStream getDataInputStream() {
        return dis;
    }

    public DataOutputStream getDataOutputStream() {
        if (os == null) {
            os = new ByteArrayOutputStream();
            dos = new DataOutputStream(os);
        }
        return dos;
    }

    public void cleanup() {
        try {
            if (dis != null)
                dis.close();
            if (dos != null)
                dos.close();
        } catch (IOException e) {
        }
    }
}
