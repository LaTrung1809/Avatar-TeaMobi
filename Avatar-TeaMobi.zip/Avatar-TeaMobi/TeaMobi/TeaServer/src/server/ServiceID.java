package server;

public class ServiceID {
	public static final byte SYSTEM = 0;
	public static final byte CARO = 1;

}
