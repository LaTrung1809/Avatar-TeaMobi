package server;

import java.util.HashMap;

public class ServerControllerManager {

    private final HashMap<Integer, ServerController> serverControllers;

    public ServerControllerManager() {
        this.serverControllers = new HashMap<Integer, ServerController>();
    }

    public void addServerController(int serviceId, ServerController serverController) {
        serverControllers.put(serviceId, serverController);
    }

    public ServerController getController(int gameKey) {
        return serverControllers.get(gameKey);
    }
}