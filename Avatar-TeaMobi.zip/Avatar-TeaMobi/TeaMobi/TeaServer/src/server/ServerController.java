package server;

import java.util.HashMap;

import io.Session;
import io.Message;


public abstract class ServerController {
	
	public int serviceId;
	
	//protected HashMap<String, Connection> connectionList;
	
	public ServerController (int serviceId) {
    	this.serviceId = serviceId;
    }
	
	public abstract boolean userLogin(Session conn);
	
	public abstract boolean userLogout(Session conn);
	
	/*public void setModel (int tableNum, TeamModel model) {
		Table table = getTable(tableNum);
		if (table != null)
			table.setModel(model);
	}*/
	
	public abstract void processGameMessage(Session conn, Message message);
}
