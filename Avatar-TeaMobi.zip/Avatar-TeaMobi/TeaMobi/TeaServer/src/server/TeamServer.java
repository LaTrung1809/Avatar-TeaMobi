package server;

import io.Session;

import java.io.IOException;
import java.net.BindException;
import java.net.ServerSocket;
import java.net.Socket;

import real.PlayerManager;
import real.RealController;
import caro.CaroServerController;
import db.HibernateUtil;

public class TeamServer {
    static final int PORT = 9123;

    public ServerControllerManager controllerManager;

    public SessionHandler serverMessageHandler;

    private static TeamServer instance = null;

    private void init() {
        controllerManager = new ServerControllerManager();
        serverMessageHandler = new SessionHandler();

        controllerManager.addServerController(ServiceID.CARO, new CaroServerController(ServiceID.CARO));
        controllerManager.addServerController(2, new RealController());
    }

    public static TeamServer getInstance() {
        if (instance == null) {
            instance = new TeamServer();
            instance.init();
        }
        return instance;
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        try {
            HibernateUtil hibernateUtil = new HibernateUtil();
            hibernateUtil.checkData("SELECT * from user");
        } catch (Exception e) {
            e.printStackTrace();
        }

        new Thread(new Runnable() {

            @Override
            public void run() {
                while (true) {
                    try {
                        Thread.sleep(10000);
                        System.out.println("Player: " + PlayerManager.getInstance().size());
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
            }

        }).start();
        getInstance().run();

    }

    public void run() {
        // Declare server socket to listen for client connections
        ServerSocket listenSocket = null;

        try {
            // Set up the server first of all
            listenSocket = new ServerSocket(PORT);
            System.out.println("Listen " + PORT);
            long curTime;
            while (true) {
                curTime = System.currentTimeMillis();
                // listen for and accept the connection
                Socket clientSocket = listenSocket.accept();

                // Try to connect client to this server
                Session conn = new Session(clientSocket, serverMessageHandler);
                conn.start();
                System.out.println("Accept socket: " + (System.currentTimeMillis() - curTime));
            }
        } catch (BindException bindEx) {
            // System.out.println (labels.get("jogre.server.already.running.on.port") + ": " + serverPort);
            System.exit(0);
        } catch (Exception genEx) {
            genEx.printStackTrace();
        }

        // Close the server down again
        try {
            // System.out.println (labels.get("jogre.games.server.closing") + ": " + serverPort);

            if (listenSocket != null)
                listenSocket.close();
        } catch (IOException ioEx) {
        }
    }

}
