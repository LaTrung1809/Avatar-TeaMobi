package server;

public class TeamModel {
	/** Game type from IJogreModel e.g. GAME_TYPE_TURN_BASED or GAME_TYPE_REAL_TIME. */
	protected int gameType;
}
