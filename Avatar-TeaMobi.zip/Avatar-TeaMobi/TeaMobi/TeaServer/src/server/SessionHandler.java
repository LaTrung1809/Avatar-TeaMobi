package server;

import io.ISessionHandler;
import io.Message;
import io.Session;
import real.PlayerManager;
import real.RealPlayer;

public class SessionHandler implements ISessionHandler {

    TeamServer server = TeamServer.getInstance();

    public void onConnectOK(Session conn) {

    }

    public void onConnectionFail(Session conn) {

    }

    public void onDisconnected(Session conn) {
        if (conn.username != null) {
            RealPlayer p = PlayerManager.getInstance().get(conn.username);
            if (p != null)
                p.outdelay = 5;
        }
    }

    public void processMessage(Session conn, Message message) {
        if (message.type == ServiceID.SYSTEM) {
        } else {
            ServerController controller = server.controllerManager.getController(message.type);
            if (controller != null)
                controller.processGameMessage(conn, message);
        }
        message.cleanup();
    }
}
