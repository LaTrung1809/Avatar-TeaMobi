package real;

import java.util.HashMap;

public class PlayerManager {
    protected PlayerManager() {

    }

    protected static PlayerManager instance;

    public static PlayerManager getInstance() {
        if (instance == null)
            instance = new PlayerManager();
        return instance;
    }

    private final HashMap<Integer, RealPlayer> players_id = new HashMap<Integer, RealPlayer>();

    private final HashMap<String, RealPlayer> players_uname = new HashMap<String, RealPlayer>();

    public void put(RealPlayer p) {
        players_id.put(p.id, p);
        players_uname.put(p.username, p);
        // System.out.println("Add player " + p.username + ", total player: " + size());
    }

    public void remove(RealPlayer p) {
        players_id.remove(p.id);
        players_uname.remove(p.username);
    }

    public void remove(String username) {
        RealPlayer p = players_uname.remove(username);
        if (p != null) {
            players_id.remove(p.id);
        }
    }

    public RealPlayer get(int id) {
        return players_id.get(id);
    }

    public RealPlayer get(String username) {
        return players_uname.get(username);
    }

    public void kickPlayer(RealPlayer p) {
        remove(p);
        p.connection.disconnect();
        p.cleanup();
        // System.out.println("Kick player "+ p.username +", total player: " + size());
    }

    public int size() {
        return players_id.size();
    }
}
