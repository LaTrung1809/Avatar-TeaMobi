package real;

public class Actor {
    public int id;
    Map map;
    public int x, y;
    public int type;
    public boolean moved = true;

    private static int baseId = 0;

    public Actor() {
        genId();
    }

    public synchronized void genId() {
        id = baseId;
        baseId++;
    }
}
