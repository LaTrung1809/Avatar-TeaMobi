package real;

import io.MessageCommand;

public class RealMessageCommand extends MessageCommand {
	public static final short MOVE = 20;
	public static final short UPDATE_POS = 21;
	public static final short GOTO_MAP = 22;
	public static final short ACTOR_INFO = 23;
	public static final short PLAYER_INFO = 24;
}
