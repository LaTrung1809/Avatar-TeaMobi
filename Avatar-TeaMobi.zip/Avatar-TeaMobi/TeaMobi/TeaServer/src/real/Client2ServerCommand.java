package real;

public class Client2ServerCommand {
    public static final short LOGIN = 1;
    public static final short LOGOUT = 2;
    public static final short CHAT_TO = 4;
    public static final short MOVE = 4;
    public static final short REQUEST_CHAR_INFO = 5;
    public static final short ATTACK = 6;
    public static final short REQUEST_MONSTER_INFO = 7;
    public static final short ATTACK_MONSTER = 9;
    public static final int PING = 11;
    // public static final short
}
