package real;

import io.Message;

import java.io.IOException;
import java.util.ArrayList;

public class Map implements Runnable {

    public int mapId;
    public final int NEAR_MAX = 20;
    
    public ArrayList<RealPlayer> players = new ArrayList<RealPlayer>();
    public ArrayList<Monster> monsters = new ArrayList<Monster>();
    int mapWidth, mapHeight;

    public Map(int id, int mapWidth, int mapHeight) {
        this.mapWidth = mapWidth;
        this.mapHeight = mapHeight;
        mapId = id;
        if (id == 0) {
            for (int i = 0; i < 200; i++) {
                Monster m0 = new Monster(this, 0, Math.abs(Monster.r.nextInt(mapWidth * 16)), Math.abs(Monster.r.nextInt(mapHeight * 16)));
                monsters.add(m0);
                MonsterManager.getInstance().put(m0);
            }
            // Monster m1 = new Monster(1, 8 * 24, 10 * 24);
            // monsters.add(m1);
            // MonsterManager.getInstance().put(m1);
        }
        new Thread(this).start();
    }

    public void playerJoin(RealPlayer player) {
        if (!players.contains(player)) {
            players.add(player);
            player.map = this;
        }
    }

    public void playerExit(RealPlayer player) {
        // alert to near players
        Message m = new Message(2, Server2ClientCommand.PLAYER_OUT);
        try {
            m.getDataOutputStream().writeShort(player.id);
        } catch (IOException e) {
        }

        for (RealPlayer p : player.nearPlayer)
            if (p.connection != null)
                p.connection.sendMessage(m);
        m.cleanup();

        players.remove(player);
        player.map = null;
    }

    public void update() {

        // boolean isNew;
        Message m = null;

        for (int i = 0; i < players.size(); i++)
            try {
                RealPlayer p = players.get(i);
                if (p.map != this)
                    continue;
                // delete actor out range
                for (int j = p.nearPlayer.size() - 1; j >= 0; j--) {
                    if (!near(p, p.nearPlayer.get(j))) {
                        p.nearPlayer.remove(j);
                    }
                }
                // find actor in range
                for (int j = 0; j < players.size(); j++) try{
                	if (p.nearPlayer.size() >= NEAR_MAX) break;
                    RealPlayer p1 = players.get(j);
                    if (p == p1)
                        continue;
                    if (near(p, p1)) {
                        if (!p.nearPlayer.contains(p1)) {
                            try {
                                if (m == null)
                                    m = new Message(2, Server2ClientCommand.ACTORS_POS);
                                m.getDataOutputStream().writeShort(p1.type); // Always 0
                                m.getDataOutputStream().writeShort(p1.id);
                                m.getDataOutputStream().writeShort(p1.x);
                                m.getDataOutputStream().writeShort(p1.y);
                            } catch (IOException ex) {
                            }
                        }
                        if (!p.nearPlayer.contains(p1))
                            p.nearPlayer.add(p1);
                    }
                }catch (Exception e) {
                }
                if (m != null) {
                    p.connection.sendMessage(m);
                    m.cleanup();
                    m = null;
                }
            } catch (Exception e) {
            }

        for (int i = players.size() - 1; i >= 0; i--) {
            RealPlayer p = players.get(i);
            // player moved
            p.moved = false;

            // player out
            if (p.outdelay > 0) {
                p.outdelay--;
                if (p.outdelay == 0) {
                    playerExit(p);
                    PlayerManager.getInstance().kickPlayer(p);
                }
            }
        }
    }

    public static boolean near(Actor p1, Actor p2) {
        return (p1.map == p2.map && Math.abs(p1.x - p2.x) < 120 && Math.abs(p1.y - p2.y) < 120);
    }

    public void processMessage(RealPlayer p, Message m) {

    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Runnable#run()
     */
    @Override
    public void run() {
        while (true) {
            long l1 = System.currentTimeMillis();
            for (Monster m : monsters) {
                m.update();
            }
            // Synchronize time
            long l2 = System.currentTimeMillis() - l1;
            if (l2 < 200)
                try {
                    Thread.sleep(200 - l2);
                } catch (InterruptedException e) {
                }
        }

    }
}
