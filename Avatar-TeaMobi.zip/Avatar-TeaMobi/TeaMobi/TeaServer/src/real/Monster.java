/**
 * 
 */
package real;

import io.Message;

import java.io.IOException;
import java.util.Random;

/**
 * @author Quynh Lam
 * 
 */
public class Monster extends Actor {
    public static final int[] HP = { 30, 50, 60 };
    public static final int[] ATTACK_DAMAGE = { 10, 10, 10 };
    public static final int[] STANDTIME = { 1000, 3000, 4000 };
    public static final int[] ATTACK_DELAY = { 1000, 3000, 4000 };

    public static Random r = new Random();
    static {
        r.setSeed(System.currentTimeMillis());
    }

    public int hp, maxhp, monster_type, dieTime, attack_Damage;
    public int default_x, default_y, toX, toY;
    public static final int TILE_SIZE = 16;
    public long lastTimeMove, moveDelay;
    public long lastTimeAttack, attackDelay;
    boolean isDead;
    public long bornTime;
    public RealPlayer target = null;

    public Monster(Map mapLiveIn, int monster_type, int default_x, int default_y) {
        super();
        map = mapLiveIn;
        type = 1;
        this.monster_type = monster_type;
        this.toX = this.x = this.default_x = default_x;
        this.toY = this.y = this.default_y = default_y;
        hp = maxhp = HP[monster_type];
        moveDelay = STANDTIME[monster_type];
        attackDelay = ATTACK_DELAY[monster_type];
        attack_Damage = ATTACK_DAMAGE[monster_type];
    }

    private void move() {
        long now = System.currentTimeMillis();
        if (now - lastTimeMove > moveDelay) {
            lastTimeMove = now;
            if (x < toX)
                x += TILE_SIZE;
            else if (y < toY)
                y += TILE_SIZE;
            else if (x > toX + TILE_SIZE)
                x -= TILE_SIZE;
            else if (y > toY + TILE_SIZE)
                y -= TILE_SIZE;
            else {
                toX = x + (r.nextInt(4) - 2) * TILE_SIZE;
                toY = y + (r.nextInt(4) - 2) * TILE_SIZE;
            }

            if (Math.abs(x - default_x) > 5 * TILE_SIZE || Math.abs(y - default_y) > 5 * TILE_SIZE) {
                target = null;
                toX = default_x;
                toY = default_y;
            }

            try {
                Message m = new Message(2, Server2ClientCommand.ACTORS_POS);
                m.getDataOutputStream().writeShort(type); // Always 1
                m.getDataOutputStream().writeShort(id);
                m.getDataOutputStream().writeShort(x);
                m.getDataOutputStream().writeShort(y);
                // Find near players
                for (int i = 0; i < map.players.size(); i++) {
                    try {
                        RealPlayer player = map.players.get(i);
                        if (Map.near(this, player)) {
                            player.connection.sendMessage(m);
                        }
                    } catch (Exception e) {
                    }
                }
            } catch (Exception e) {
            }
        }
    }

    private void attack() {
        long now = System.currentTimeMillis();
        if (now - lastTimeAttack > attackDelay) {
            lastTimeAttack = now;
            try {
                Message m = new Message(2, Server2ClientCommand.MONSTER_ATTACK_PLAYER);
                m.getDataOutputStream().writeShort(id); // A
                m.getDataOutputStream().writeShort(target.id); // B
                int ahp = 5;
                m.getDataOutputStream().writeShort(ahp); // HP mat di
                m.getDataOutputStream().writeShort(target.hp - ahp); // HP con lai
                target.hp -= ahp;
                for (int i = 0; i < target.nearPlayer.size(); i++) {
                    RealPlayer p2 = target.nearPlayer.get(i);
                    p2.connection.sendMessage(m);
                }
                target.connection.sendMessage(m);
                m.cleanup();
            } catch (IOException e1) {
            }
        }
    }

    public void update() {
        if (isDead) {
            long now = System.currentTimeMillis();
            if (now > bornTime) {
                bornTime = now;
                isDead = false;
            }
            return;
        }
        if (target == null) {
            move();
        } else {
            if (target.map != map) {
                target = null;
                return;
            }
            if (Math.abs(target.x - x) < 16 && Math.abs(target.y - y) < 16) {
                attack();
            } else {
                toX = target.x;
                toY = target.y;
                move();
            }
        }
    }
}
