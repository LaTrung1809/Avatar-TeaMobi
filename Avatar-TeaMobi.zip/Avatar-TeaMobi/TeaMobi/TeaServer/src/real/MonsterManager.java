package real;

import java.util.HashMap;

public class MonsterManager {
    protected MonsterManager() {

    }

    protected static MonsterManager instance;

    public static MonsterManager getInstance() {
        if (instance == null)
            instance = new MonsterManager();
        return instance;
    }

    private final HashMap<Integer, Monster> players_id = new HashMap<Integer, Monster>();

    public void put(Monster p) {
        players_id.put(p.id, p);
    }

    public void remove(Monster p) {
        players_id.remove(p.id);
    }

    public Monster get(int id) {
        return players_id.get(id);
    }
}
