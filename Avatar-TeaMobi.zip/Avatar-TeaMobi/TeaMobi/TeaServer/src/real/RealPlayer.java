package real;

import io.Session;

import java.util.ArrayList;

public class RealPlayer extends Actor {

    public String username;

    public String charname;

    public Session connection;

    public ArrayList<RealPlayer> nearPlayer = new ArrayList<RealPlayer>();

    public int hp = 100, maxhp = 100;
    public int attackDamage = 10;

    public int outdelay = 0;

    public RealPlayer(Session conn) {
        super();
        type = 0;
        connection = conn;
    }

    public void cleanup() {
        nearPlayer.removeAll(nearPlayer);
        nearPlayer = null;
        connection = null;
    }
}
