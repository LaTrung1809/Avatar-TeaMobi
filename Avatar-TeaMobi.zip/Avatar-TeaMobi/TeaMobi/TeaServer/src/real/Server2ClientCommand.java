package real;

public class Server2ClientCommand {
    public static final short LOGIN_SUCESS = 1;
    public static final short LOGIN_FAIL = 2;
    public static final short MAIN_CHAR_INFO = 3;
    public static final short ACTORS_POS = 4;
    public static final int CHAR_INFO = 5;
    public static final short ATTACK_RESAUT = 6;
    public static final short MONSTER_INFO = 7;
    public static final short PLAYER_OUT = 8;
    public static final short ATTACK_MONSTER_RESAUT = 9;
    public static final short MONSTER_ATTACK_PLAYER = 10;
    public static final int PING = 11;
    public static final int CHANGE_MAP = 12;
}
