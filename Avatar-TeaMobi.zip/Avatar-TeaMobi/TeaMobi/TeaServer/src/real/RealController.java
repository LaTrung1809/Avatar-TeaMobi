package real;

import io.Message;
import io.Session;

import java.io.DataInputStream;
import java.io.IOException;
import java.util.ArrayList;

import server.ServerController;

public class RealController extends ServerController implements Runnable {

    // public HashMap<Integer, RealPlayer> players = new HashMap<Integer, RealPlayer>();

    public ArrayList<Map> mapList = new ArrayList<Map>();

    public boolean running = true;

    public RealController() {
        super(2);
        for (int i = 0; i < 30; i++) {
            mapList.add(new Map(i, 200, 200));
        }
        new Thread(this).start();
    }

    @Override
    public void processGameMessage(Session conn, Message message) {
        // RealPlayer p = players.get(conn.username);
        RealPlayer p = null;
        DataInputStream dis = message.getDataInputStream();
        switch (message.command) {
        case Client2ServerCommand.LOGIN:
            String uname,
            pwd;
            try {
                uname = dis.readUTF();
                pwd = dis.readUTF();
                int mapid = dis.readByte();
                p = PlayerManager.getInstance().get(uname);
                Message m = new Message(serviceId, Server2ClientCommand.LOGIN_SUCESS);
                conn.sendMessage(m);
                m.cleanup();
                m = new Message(serviceId, Server2ClientCommand.MAIN_CHAR_INFO);
                if (p != null) {
                    p.connection.cleanup();
                    p.connection = conn;
                } else {
                    p = new RealPlayer(conn);
                    p.username = uname;
                    p.charname = uname;
                    p.map = mapList.get(mapid);
                    p.x = 30 + Math.abs(Monster.r.nextInt(100));
                    p.y = 30 + Math.abs(Monster.r.nextInt(100));
                    PlayerManager.getInstance().put(p);
                }
                m.getDataOutputStream().writeShort(p.id);
                m.getDataOutputStream().writeUTF(p.charname);
                m.getDataOutputStream().writeShort(p.x);
                m.getDataOutputStream().writeShort(p.y);
                m.getDataOutputStream().writeShort(p.hp);
                m.getDataOutputStream().writeShort(p.maxhp);
                conn.sendMessage(m);
                m.cleanup();
                // Send map Info
                Message m2 = new Message(serviceId, Server2ClientCommand.CHANGE_MAP);
                m2.getDataOutputStream().writeByte(mapid);
                conn.sendMessage(m2);
                m2.cleanup();
                //
                p.map.playerJoin(p);
                conn.username = uname;
            } catch (IOException e1) {
            }
            break;

        case Client2ServerCommand.REQUEST_CHAR_INFO:
            try {
                int id = dis.readUnsignedShort();
                RealPlayer ch = PlayerManager.getInstance().get(id);
                if (ch == null)
                    break;
                Message m = new Message(serviceId, Server2ClientCommand.CHAR_INFO);
                m.getDataOutputStream().writeShort(ch.id);
                m.getDataOutputStream().writeUTF(ch.charname);
                m.getDataOutputStream().writeShort(ch.x);
                m.getDataOutputStream().writeShort(ch.y);
                m.getDataOutputStream().writeShort(ch.hp);
                m.getDataOutputStream().writeShort(ch.maxhp);
                conn.sendMessage(m);
                m.cleanup();
            } catch (IOException e1) {
            }
            break;

        case Client2ServerCommand.REQUEST_MONSTER_INFO:
            try {
                int id = dis.readUnsignedShort();
                Monster ch = MonsterManager.getInstance().get(id);
                Message m = new Message(serviceId, Server2ClientCommand.MONSTER_INFO);
                m.getDataOutputStream().writeShort(ch.id);
                m.getDataOutputStream().writeShort(ch.monster_type);
                m.getDataOutputStream().writeShort(ch.x);
                m.getDataOutputStream().writeShort(ch.y);
                m.getDataOutputStream().writeShort(ch.hp);
                m.getDataOutputStream().writeShort(ch.maxhp);
                conn.sendMessage(m);
                m.cleanup();
            } catch (IOException e1) {
            }
            break;

        case Client2ServerCommand.ATTACK:
            p = PlayerManager.getInstance().get(conn.username);
            try {
                RealPlayer p1 = PlayerManager.getInstance().get(dis.readShort());
                short skill = dis.readShort();
                Message m = new Message(serviceId, Server2ClientCommand.ATTACK_RESAUT);
                m.getDataOutputStream().writeShort(p.id); // A
                m.getDataOutputStream().writeShort(p1.id); // B
                m.getDataOutputStream().writeShort(skill); // skill id
                int ahp = 0;
                // if (Math.abs(p.x - p1.x) < 50 && Math.abs(p.y - p1.y) < 50) {
                ahp = 20;
                // }
                m.getDataOutputStream().writeShort(ahp); // HP mat di
                m.getDataOutputStream().writeShort(p1.hp - ahp); // HP con lai
                p1.hp -= ahp;
                for (int i = 0; i < p.nearPlayer.size(); i++) {
                    RealPlayer p2 = p.nearPlayer.get(i);
                    p2.connection.sendMessage(m);
                }
                p.connection.sendMessage(m);
                m.cleanup();
            } catch (IOException e1) {
            }
            break;

        case Client2ServerCommand.ATTACK_MONSTER:
            p = PlayerManager.getInstance().get(conn.username);
            try {
                Monster mt = MonsterManager.getInstance().get(dis.readShort());
                if (mt.isDead)
                    break;
                short skill = dis.readShort();
                mt.target = p;
                Message m = new Message(serviceId, Server2ClientCommand.ATTACK_MONSTER_RESAUT);
                m.getDataOutputStream().writeShort(p.id); // A
                m.getDataOutputStream().writeShort(mt.id); // B
                m.getDataOutputStream().writeShort(skill); // skill id
                // if (Math.abs(p.x - mt.x) > 50 || Math.abs(p.y - mt.y) > 50) {
                // break;
                // }
                int ahp = p.attackDamage;
                m.getDataOutputStream().writeShort(ahp); // HP mat di
                m.getDataOutputStream().writeShort(mt.hp - ahp); // HP con lai
                mt.hp -= ahp;

                for (int i = 0; i < p.nearPlayer.size(); i++) {
                    RealPlayer p2 = p.nearPlayer.get(i);
                    p2.connection.sendMessage(m);
                }
                p.connection.sendMessage(m);
                m.cleanup();

                if (mt.hp <= 0) {
                    mt.bornTime = System.currentTimeMillis() + 10000;
                    mt.isDead = true;
                    mt.target = null;
                    mt.hp = mt.maxhp;
                }
            } catch (IOException e1) {
            }
            break;

        case Client2ServerCommand.LOGOUT:
            if (conn.username != null) {
                p = PlayerManager.getInstance().get(conn.username);
                if (p != null)
                    p.outdelay = 5;
                // PlayerManager.getInstance().remove(conn.username);
            }
            // conn.cleanup();
            break;
        case Client2ServerCommand.MOVE:
            p = PlayerManager.getInstance().get(conn.username);
            try {
                p.x = dis.readUnsignedShort();
                p.y = dis.readUnsignedShort();
                p.moved = true;
                Message m = new Message(2, Server2ClientCommand.ACTORS_POS);
                m.getDataOutputStream().writeShort(p.type); // Always 0
                m.getDataOutputStream().writeShort(p.id);
                m.getDataOutputStream().writeShort(p.x);
                m.getDataOutputStream().writeShort(p.y);
                for (int i = 0; i < p.nearPlayer.size(); i++) {
                    if (p.nearPlayer.get(i) instanceof RealPlayer) {
                        try {
                            RealPlayer p1 = p.nearPlayer.get(i);
                            p1.connection.sendMessage(m);
                        } catch (Exception e) {
                        }
                    }
                }
                p.connection.sendMessage(m);
                m.cleanup();
            } catch (IOException e) {
            }
            break;
        case RealMessageCommand.GOTO_MAP:
            p = PlayerManager.getInstance().get(conn.username);
            try {
                if (p.map != null) {
                    p.map.playerExit(p);
                }
                int mapId = dis.readUnsignedShort();
                Map newMap = mapList.get(mapId);
                if (newMap != null) {
                    p.map = newMap;
                    newMap.playerJoin(p);
                }
                p.moved = true;
            } catch (IOException e) {
            }
            break;
        case Client2ServerCommand.PING:
            Message m = new Message(2, Server2ClientCommand.PING);
            conn.sendMessage(m);
            break;
        }
    }

    @Override
    public boolean userLogin(Session conn) {
        if (PlayerManager.getInstance().get(conn.username) != null)
            return false;
        RealPlayer player = new RealPlayer(conn);
        PlayerManager.getInstance().put(player);
        // conn.serviceId = serviceId;
        System.out.println("User login board game: " + conn.username);
        /*
         * Message m = getRoomListMessage(); conn.sendMessage(m); m.cleanup();
         */
        return true;
    }

    @Override
    public boolean userLogout(Session conn) {

        return false;
    }

    @Override
    public void run() {
        while (running) {
            long l1 = System.currentTimeMillis();

            for (Map map : mapList)
                map.update();

            long l2 = System.currentTimeMillis() - l1;
            if (l2 < 1000)
                try {
                    Thread.sleep(1000 - l2);
                } catch (InterruptedException e) {
                }
        }
    }

    public RealPlayer getPlayer(String username) {

        return null;
    }

}
