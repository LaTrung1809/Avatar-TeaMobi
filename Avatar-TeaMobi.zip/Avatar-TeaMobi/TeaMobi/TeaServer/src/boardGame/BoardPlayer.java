package boardGame;

import io.Session;

public class BoardPlayer {
	/** Username of User. */
	public String username;
	
	public int gameId;
	
	public int roomNumber;
	
	public int tableNumber;
	
	public int seatNumber;
	
	public Session connection;

	/** Score rating of User. */
	public int rating, wins, draws, loses, streak;
	
	public BoardPlayer(int gameId, Session conn)
	{
		this.gameId = gameId;
		connection = conn;
		username = conn.username;
	}
}
