package boardGame;

import io.MessageCommand;

public class BoardMessageCommand extends MessageCommand {
	public static final short ROOM_LIST = 4;
	public static final short TABLE_LIST = 5;
	public static final short JOIN_ROOM = 6;
	public static final short JOIN_TABLE = 7;
	public static final short CHAT_TABLE = 8;
	public static final short READY = 9;
	public static final short START_GAME = 10;
	public static final short KICK_PLAYER = 11;
	public static final short PLAYER_JOIN_TABLE = 12;
	public static final short PLAYER_EXIT_TABLE = 14;
}
