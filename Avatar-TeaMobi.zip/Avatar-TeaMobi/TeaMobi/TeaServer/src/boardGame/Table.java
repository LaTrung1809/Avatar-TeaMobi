package boardGame;
import io.Message;
import io.MessageCommand;

import java.io.DataInputStream;
import java.io.IOException;
import java.util.Date;

import server.TeamModel;


public class Table {
	// Declare fields
	private int tableNumber;
	
	private int roomNumber;
	
	// time started
	private Date startTime;                
	
	private BoardPlayer[] players;  
	// list of players
	private boolean[] ready;
	
	private TeamModel model;
	
	private boolean playing = false;
	// table password
	private String password;
	// table owner
	private BoardPlayer owner;
	
	private BoardPlayer currentPlayer;
	
	private long currentPlayerTime;
	
	private int timeForPlay = 30000;
	
	private BoardGameController game;
	
	public Table(BoardGameController game, int roomNumber, int tableNumber)	{
		this.game = game;
		int maxPlayer = game.maxNumOfPlayers;
		this.tableNumber = tableNumber;
		this.roomNumber = roomNumber;
		players = new BoardPlayer[maxPlayer]; 
		ready = new boolean[maxPlayer];
	}
	
	public void setModel (TeamModel model) {
		this.model = model;
	}
	
	public TeamModel getModel () {
		return model;
	}
	
	public int getTableNumber()	{
		return tableNumber;
	}
	
	// return seat number, -1 mean can not join
	public int addPlayer(BoardPlayer player) {
		if (playing) return -1;
		for (int i=0; i<players.length; i++) {
			if (players[i]==null) {
				players[i] = player;
				player.seatNumber = i;
				if (owner==null) owner = player;
				playerJoinNotify(player, i);
				return i;
			}
		}
		return -1;
	}
	
	private void playerJoinNotify(BoardPlayer player, int seatNum)
	{
		Message m = new Message(game.serviceId, BoardMessageCommand.PLAYER_JOIN_TABLE);
		Message m1 = new Message(game.serviceId, BoardMessageCommand.JOIN_TABLE);
		try {
			m.getDataOutputStream().writeByte(seatNum);
			m.getDataOutputStream().writeUTF(player.username);
			for (int i=0; i<players.length; i++) {
				if (players[i]!=null) {
					if (players[i]!=player) players[i].connection.sendMessage(m);
					m1.getDataOutputStream().writeUTF(players[i].username);
				}
				else
					m1.getDataOutputStream().writeUTF("");
			}
			m.cleanup();
			player.connection.sendMessage(m1);
			m1.cleanup();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void playerReady(BoardPlayer player, boolean ready)
	{
		for (int i=0; i<players.length; i++) {
			if (players[i]==player) {
				this.ready[i] = ready;
				playerReadyNotify(i, ready);
				break;
			}
		}
	}
	
	private void playerReadyNotify(int seatNum, boolean ready)
	{
		Message m = new Message(game.serviceId, BoardMessageCommand.READY);
		try {
			m.getDataOutputStream().writeByte(seatNum);
			m.getDataOutputStream().writeBoolean(ready);
			for (int i=0; i<players.length; i++) {
				if (players[i]!=null && i!=seatNum) {
					players[i].connection.sendMessage(m);
				}
			}
			m.cleanup();
		} catch (IOException e) {}
	}
	
	public boolean removePlayer(BoardPlayer player)	{
		
		for (int i=0; i<players.length; i++) {
			if (players[i]==player) {
				players[i] = null;
				player.seatNumber = -1;
				playerJoinNotify(player, -1);
				return true;
			}
		}
		return false;
	}
	
	private void playerExitNotify(int seatNum)
	{
		Message m = new Message(game.serviceId, BoardMessageCommand.PLAYER_EXIT_TABLE);
		
		try {
			m.getDataOutputStream().writeByte(seatNum);
			for (int i=0; i<players.length; i++) {
				if (players[i]!=null && i!=seatNum) {
					players[i].connection.sendMessage(m);
				}
			}
			m.cleanup();
		} catch (IOException e) {}
	}
	
	public int countPlayer() {
		int count = 0;
		for (int i=0; i<players.length; i++) {
			if (players[i]!=null) {
				count++;
			}
		}
		return count;
	}
	
	public int getMaxPlayer() {
		return players.length;
	}
	
	public BoardPlayer getPlayer(int seatNum) {
		return players[seatNum];
	}
	
	public boolean isPlaying() {
		return playing;
	}
	
	public boolean isReady(int seatNum)	{
		return ready[seatNum];
	}
	
	public void setReadyStatus(int seatNum, boolean value) {
		ready[seatNum] = value;
	}
	
	public BoardPlayer getOwner() {
		return owner;
	}
	
	public void kickPlayer(BoardPlayer player)
	{
		for (int i=0; i<players.length; i++) 
		{	
			if (players[i]==player) 
			{	
				players[i] = null;
				ready[i] = false;
			}
		}
	}
	
	public boolean startGame() 
	{
		if (countPlayer()>=game.minNumOfPlayers) 
		{	
			for (int i=0; i<players.length; i++) 
			{	
				if (players[i]!=null && ready[i]==false) 
				{	
					return false;
				}
			}
			playing = true;
			return true;
		}
		return false;
	}
	
	public synchronized void nextPlayer(boolean auto)
	{
		if (auto)
		{
			if (System.currentTimeMillis()-currentPlayerTime < timeForPlay)
				return;
		}
		for (int i=0; i<players.length; i++) 
		{	
			if (currentPlayer!=null && players[i]==currentPlayer) 
			{	
				int j;
				do {
					j = (i + 1) % players.length;
				} while (players[j]!=null);
				currentPlayer = players[j];
				break;
			}
			if (currentPlayer==null && players[i]!=null)
			{
				currentPlayer = players[i];
				break;
			}
		}
		currentPlayerTime = System.currentTimeMillis();
	}
	
	public void update()
	{
		if (!playing) return;
		// next player if timeout
		nextPlayer(true);
	}
	
	public void processTableMessage(BoardPlayer player, Message message)
	{
		System.out.println("process table message: "+player.username);
		DataInputStream dis = message.getDataInputStream();
		switch (message.command)
		{
		case BoardMessageCommand.JOIN_TABLE:
	    	addPlayer(player);
	    	break;
	    
		case BoardMessageCommand.READY:
	    	try {
		    	boolean ready = dis.readBoolean();
		    	playerReady(player, ready);		
	    	} catch (IOException e) {}
	    	break;
	    
	    case BoardMessageCommand.START_GAME:
	    	if (player==owner) startGame();
	    	break;
	    	
	    case BoardMessageCommand.KICK_PLAYER:
	    	if (player==owner) {
	    		
	    	}
	    	break;
	    
	    case BoardMessageCommand.CHAT_TABLE:
	    	try {
		    	String content = dis.readUTF();
		    	Message m = new Message(game.serviceId, BoardMessageCommand.CHAT_TABLE);
		    	m.getDataOutputStream().writeByte(0);
		    	m.getDataOutputStream().writeByte(tableNumber);
		    	m.getDataOutputStream().writeUTF(player.username);
		    	m.getDataOutputStream().writeUTF(content);
		    	for (int i=0; i<players.length; i++) {
					if (players[i]!=null && players[i]!=player) {
						players[i].connection.sendMessage(m);
					}
				}
		    	m.cleanup();
	    	} catch (IOException e) {
	    		e.printStackTrace();
	    	}
	    	break;
		}
	}
}
