package boardGame;

import io.Session;
import io.Message;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import server.ServerController;

public abstract class BoardGameController extends ServerController{
	
	/** List of users which are currently connected to the server. */
	protected HashMap<String, BoardPlayer> playerList = new HashMap<String, BoardPlayer>();

	/** List of tables current being played on this server. */
	protected ArrayList<Room> roomList = new ArrayList<Room>();
	
	/** Minimum and maximum number of players on table. */
	public int minNumOfPlayers, maxNumOfPlayers;
	
	
	public BoardGameController(int serviceId, int minNumOfPlayers, int maxNumOfPlayers) {
		super(serviceId);
		this.minNumOfPlayers = minNumOfPlayers;
		this.maxNumOfPlayers = maxNumOfPlayers;
		for (int i=0; i<10; i++)
		{
			Room r = new Room(i, 100, this);
			roomList.add(r);
		}
	}
	
	public boolean userLogin(Session conn)
	{
		if (playerList.containsKey(conn.username)) return false;
		BoardPlayer player = new BoardPlayer(serviceId, conn);
		playerList.put(player.username, player);
		//conn.serviceId = serviceId;
		System.out.println("User login board game: "+conn.username);
		Message m = getRoomListMessage();
		conn.sendMessage(m);
		m.cleanup();
		return true;
	}
	
	public boolean userLogout(Session conn)
	{
		if (playerList.remove(conn.username) != null) return true;
		return false;
	}
	
	public Message getRoomListMessage()
	{
		Message m = new Message(serviceId, BoardMessageCommand.ROOM_LIST);
		try {
			for (int i=0; i<roomList.size(); i++)
			{
				Room r = roomList.get(i);
				// write room number
				m.getDataOutputStream().writeByte(r.roomNumber);
				// write count player in room
				m.getDataOutputStream().writeByte(r.countPlayer());
				// write max player allow in room
				m.getDataOutputStream().writeByte(r.maxPlayer);
			}
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
		return m;
	}
	
	public void processGameMessage(Session conn, Message message) {
		DataInputStream dis = message.getDataInputStream();
	    switch (message.command)
	    {
	    case BoardMessageCommand.ROOM_LIST:
	    	break;
	    case BoardMessageCommand.JOIN_ROOM:
	    	if (conn.username!=null)
	    	{
	    		BoardPlayer p = playerList.get(conn.username);
	    		int rNum = -1;
	    		try {
					rNum = dis.readUnsignedByte();
				
		    		if (rNum!=-1)
		    		{
		    			Message m;
		    			Room r = roomList.get(rNum);
		    			if (r.addPlayer(p))
		    			{
		    				m = r.getTableListMessage();
		    			}
		    			else
		    			{
		    				m = new Message(serviceId, BoardMessageCommand.JOIN_ROOM);
		    				m.getDataOutputStream().writeByte(1);
		    			}
		    			conn.sendMessage(m);
		    			m.cleanup();
		    		}
	    		} catch (IOException e) {}
	    	}
	    	break;
	    
	    case BoardMessageCommand.TABLE_LIST:
	    	break;
	    	
	    case BoardMessageCommand.JOIN_TABLE:
	    case BoardMessageCommand.READY:
	    case BoardMessageCommand.START_GAME:
	    case BoardMessageCommand.CHAT_TABLE:
	    case BoardMessageCommand.KICK_PLAYER:
	    	if (conn.username!=null)
	    	{
	    		BoardPlayer p = playerList.get(conn.username);
	    		try {
					int rNum = dis.readUnsignedByte();
					int tNum = dis.readUnsignedByte();
					Room room = roomList.get(rNum);
					if (room.players.containsKey(conn.username))
					{
						Table table = room.tableList.get(tNum);
						if (table!=null) table.processTableMessage(p, message);
					}
	    		} catch (IOException e) {
	    			e.printStackTrace();
	    		}
	    	}
	    	break;
	    }
	}
}
