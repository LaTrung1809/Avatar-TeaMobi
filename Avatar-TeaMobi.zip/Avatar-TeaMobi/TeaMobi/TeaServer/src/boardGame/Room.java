package boardGame;

import io.Message;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Room {
	
	public int roomNumber;
	
	public String roomName;
	
	public int maxPlayer;
	
	public HashMap<String, BoardPlayer> players = new HashMap<String, BoardPlayer>();
	
	public ArrayList<Table> tableList = new ArrayList<Table>();
	
	private BoardGameController game;
	
	public Room(int number, int maxPlayer, BoardGameController game)
	{
		this.maxPlayer = maxPlayer;
		this.game = game;
		this.roomNumber = number;
		for (int i=0; i<20; i++)
		{
			Table t = new Table(game, number, i);
			tableList.add(t);
		}
	}
	
	public int countPlayer()
	{
		return players.size();
	}
	
	public boolean addPlayer(BoardPlayer player)
	{
		if (players.containsKey(player.username) || countPlayer()>=maxPlayer) return false;
		players.put(player.username, player);
		player.roomNumber = roomNumber;
		return true;
	}
	
	public Message getTableListMessage()
	{
		Message m = new Message(game.serviceId, BoardMessageCommand.TABLE_LIST);
		try {
			for (int i=0; i<tableList.size(); i++)
			{
				Table t = tableList.get(i);
				// write room number
				m.getDataOutputStream().writeByte(t.getTableNumber());
				// write count player in table
				m.getDataOutputStream().writeByte(t.countPlayer());
				// write max player allow in table
				m.getDataOutputStream().writeByte(t.getMaxPlayer());
			}
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
		return m;
	}

}
