package io;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import server.ServiceID;

public class Message {
    public int type;
    public int command;
    private ByteArrayOutputStream os = null;
    private DataOutputStream dos = null;
    private ByteArrayInputStream is = null;
    private DataInputStream dis = null;
    
    private byte[] bytes = null;

    public Message() {
        
    }

    public Message(int type, int command) {
        this.type = type;
        this.command = command;
    }

    Message(int type, int command, byte[] data) {
        this.type = type;
        this.command = command;
        is = new ByteArrayInputStream(data);
        dis = new DataInputStream(is);
    }

    public byte[] toByteArray() {
    	int datalen = 0;
    	byte[] data = null;
    	if (bytes==null)
    	{
    		try {
    			if (dos!=null)
    			{
					dos.flush();
					data = os.toByteArray();
					datalen = data.length;
					dos.close();
    			}
				ByteArrayOutputStream bos1 = new ByteArrayOutputStream(6+datalen);
				DataOutputStream dos1 = new DataOutputStream(bos1);
				dos1.writeByte(type);
				dos1.writeShort(command);
				dos1.writeShort(datalen);
				if (datalen>0) dos1.write(data);
				bytes = bos1.toByteArray();
				dos1.close();
			} catch (IOException e) {}
    	}
    	return bytes;
    }

    public DataInputStream getDataInputStream() {
        return dis;
    }
    
    public DataOutputStream getDataOutputStream() {
    	if (os==null)
    	{
    		os = new ByteArrayOutputStream();
            dos = new DataOutputStream(os);
    	}
    	return dos;
    }
    
    /*public void writeByte(int value) throws IOException
    {
    	getDataOutputStream().writeByte(value);
    }
    
    public void writeShort(int value) throws IOException
    {
    	getDataOutputStream().writeShort(value);
    }
    
    public void writeInt(int value) throws IOException
    {
    	getDataOutputStream().writeInt(value);
    }
    
    public void writeUTF(String value) throws IOException
    {
    	getDataOutputStream().writeUTF(value);
    }*/
    
    public void cleanup()
    {
		try {
			if (dis!=null) dis.close();
			if (dos!=null) dos.close(); 
			bytes = null;
		} catch (IOException e) {}
    }
}
