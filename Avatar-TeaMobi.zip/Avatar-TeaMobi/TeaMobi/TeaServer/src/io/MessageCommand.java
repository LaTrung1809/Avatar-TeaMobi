package io;

public class MessageCommand {
	public static final short LOGIN = 1;
	public static final short LOGOUT = 2;
	public static final short CHAT_TO = 3;
	
}
