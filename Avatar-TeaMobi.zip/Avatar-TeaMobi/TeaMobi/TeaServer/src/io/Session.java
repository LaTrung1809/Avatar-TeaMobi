package io;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;

import util.Logger;

public class Session extends Thread {

    Logger logger = new Logger(this.getClass());

    protected boolean connected = false;

    protected Socket socket;

    public String username = null;

    // public int serviceId;

    // protected boolean loop = true;

    protected DataInputStream dis;

    private OutputStream os;

    ISessionHandler messageHandler;

    private ArrayList<byte[]> sendDatas = new ArrayList<byte[]>();

    private final Object LOCK = new Object();
    
    private static int baseId = 0;
    
    public int id;
    
    public long connectTime;

    public Session(Socket socket, ISessionHandler handler) {
    	id = baseId++;
    	connectTime = System.currentTimeMillis();
        try {
            logger.debug("Session", "Creating new in/out streams.");
            setSocket(socket);
            messageHandler = handler;
            connected = true;
            messageHandler.onConnectOK(this);
        } catch (IOException ioEx) {
            logger.error("Session", "IO Exception.");
            // logger.stacktrace(ioEx);
        }
    }

    protected void setSocket(Socket socket) throws IOException {
        this.socket = socket;

        if (socket != null) {
            dis = new DataInputStream(socket.getInputStream());
            os = socket.getOutputStream();
        }
    }

    @Override
    public void run() {
        // logger.debug("run", "Staring thread.");
        new Thread(new Runnable() {
            public void run() {
                doSendMessage();
            }
        }).start();

        Message message;
        try {
            while (connected) {
                message = readMessage();
                try {
                    messageHandler.processMessage(this, message);
                } catch (Exception e) {
                	//process message exception
                    //e.printStackTrace();
                }
            }
        } catch (Exception e) {
            //e.printStackTrace();
        	//System.out.println("Socket close (on read): " + id + " " + username);
        	logger.error("run", "Exception: " + e.toString() + " : " + id + " : " + username);
        }
        
        disconnect();
        dis = null;    
    }

    private Message readMessage() throws IOException {
        // read type of message
        int type = dis.readUnsignedByte();
        // read message command
        int cmd = dis.readUnsignedShort();
        // read size of data
        int size = dis.readUnsignedShort();

        byte data[] = new byte[size];
        int len = 0;
        int byteRead = 0;
        while (len != -1 && byteRead < size) {
            len = dis.read(data, byteRead, size - byteRead);
            if (len > 0) {
                byteRead += len;
            }
        }
        Message msg = new Message(type, cmd, data);
        return msg;
    }

    public void sendMessage(Message m) {
        // logger.debug("sendMessage", m.type + " " + m.command);
        // System.out.println("sendMessage" + m.type + " " + m.command);
        // new Sender(m);
        if (connected)
        {    
	        sendDatas.add(m.toByteArray());
	        synchronized (LOCK) {
	            LOCK.notify();
	        }
        }

        /*
         * if (!sending) { sending = true; new Thread(new Runnable(){ public void run(){ doSendMessage(); sending = false; } }).start(); }
         */
    }

    private void doSendMessage() {
        byte[] bytes = null;
        while (connected) {
        	try {
	            while (sendDatas.size() > 0) {
	                bytes = sendDatas.remove(0);
	                //if (bytes == null) continue;
	                os.write(bytes);
	            }
	            os.flush();
        	} catch (Exception e) {
                logger.error("doSenMessage", "Exception: " + e.toString() + " : " + id + " : " + username);
                disconnect();
                break;
            }
            synchronized (LOCK) {
                try {
                    LOCK.wait();
                } catch (InterruptedException e) {
                }
            }
        }
        
        sendDatas.removeAll(sendDatas);
        sendDatas = null;
        os = null;
    }

    public boolean isConnected() {
        return connected;
    }

    public void disconnect() {
    	if (connected)
    	{
    		try {
				socket.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
	        connected = false;
	        messageHandler.onDisconnected(this);
	        synchronized (LOCK) {
	            LOCK.notify();
	        }
    	}
        // cleanup();
    }

    public void cleanup() {

    }

    /*
     * private class Sender implements Runnable { Message m;
     * 
     * public Sender(Message message) { m = message; new Thread(this).run(); }
     * 
     * public void run() { doSendMessage(); } }
     */
}
