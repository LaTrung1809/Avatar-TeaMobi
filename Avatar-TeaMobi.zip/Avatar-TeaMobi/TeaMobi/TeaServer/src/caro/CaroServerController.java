package caro;

import java.io.IOException;

import boardGame.*;

import io.Session;
import io.Message;
import server.ServerController;

public class CaroServerController extends BoardGameController {
	
	public CaroServerController (int serviceId) {
		super(serviceId, 2, 2);
    }
    
    /**
     * Create a new model when the game starts.
     */
    public void startGame (int roomNumber, int tableNum) {
    	Room r = roomList.get(roomNumber);
    	Table t = r.tableList.get(tableNum);
    	t.setModel(new CaroModel());
    }
    
    public void processGameMessage(Session conn, Message message) {
    	super.processGameMessage(conn, message);
	    switch (message.command)
	    {
	    case CaroMessageCommand.PLAY:
	    	try {
				int x = message.getDataInputStream().readUnsignedByte();
				int y = message.getDataInputStream().readUnsignedByte();
				BoardPlayer player = playerList.get(conn.username);
				Room room = roomList.get(player.roomNumber);
				Table table = room.tableList.get(player.tableNumber);
				CaroModel model = (CaroModel)table.getModel();
				//TODO: code model process
			} catch (IOException e) {
				e.printStackTrace();
			}
	    	
	    	break;
	    }
	}
}
