package caro;

import io.MessageCommand;

public class CaroMessageCommand extends MessageCommand {
	public static final short CHAT = 100;
	public static final short JOIN_TABLE = 101;
	public static final short READY = 102;
	public static final short PLAY = 103;
	public static final short OUT = 104;
	public static final short INVITE = 105;
	public static final short KICH = 106;
	public static final short START = 107;
}
