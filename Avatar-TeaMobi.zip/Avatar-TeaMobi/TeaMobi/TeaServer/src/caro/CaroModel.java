package caro;

import server.*;

public class CaroModel extends TeamModel {
	public static final int BLANK = 0;
	public static final int X     = 1;
	public static final int O     = -1;
	
	private int size = 16;
	private int [][] data = new int [size][size];
	
	public CaroModel() {
		super ();
		reset ();
	}
	
	// reset the model back to zeros
	public void reset () {
		for (int x = 0; x < size; x++) {
			for (int y = 0; y < size; y++) {
				data [x][y] = BLANK;
			}
		}
	}
	
	// return data at a particular point
	public int getData (int x, int y) {
		return data [x][y];
	}
	
	// set data at a point
	public void setData (int x, int y, int value) {
		data [x][y] = value;
		
	}
	
	// return true if the game is won by this player
	public boolean isGameWon (int player) {	
		//TODO: code calculate game over
		return false;		
	}
}
